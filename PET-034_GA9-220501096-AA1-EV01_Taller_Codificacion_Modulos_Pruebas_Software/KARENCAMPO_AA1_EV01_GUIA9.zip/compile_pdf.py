#!/usr/bin/env python3
# ==============================================================================
# COMPILADOR DE INFORME TÉCNICO FORMAL PDF Y WORD (SENA ADSO GUÍA 9 - AA1-EV01)
# Evidencia: GA9-220501096-AA1-EV01 - Taller sobre codificación de módulos del software
# Aprendiz: Karen Yuliana Campo | Ficha: 3186681 | CTPI Popayán - Regional Cauca
# ==============================================================================

import os
import subprocess
import shutil

BASE_DIR = '/home/danilo/Escritorio/Karen/SENA/CDE/Evidencias/PET-034_GA9-220501096-AA1-EV01_Taller_Codificacion_Modulos_Pruebas_Software'
DOCS_DIR = os.path.join(BASE_DIR, 'docs')
CAP_DIR = os.path.join(BASE_DIR, 'capturas')
ENTREGA_DIR = '/home/danilo/Escritorio/Karen/SENA/ENTREGA_ZAJUNA_GA9-220501096-AA1-EV01'

os.makedirs(DOCS_DIR, exist_ok=True)
os.makedirs(ENTREGA_DIR, exist_ok=True)

cap1_path = os.path.join(CAP_DIR, 'captura_01_instalacion_herramientas_testing.png')
cap2_path = os.path.join(CAP_DIR, 'captura_02_ejecucion_pruebas_modulos_pizzeria.png')
cap3_path = os.path.join(CAP_DIR, 'captura_03_dashboard_reporte_pruebas_cobertura.png')

html_content = f"""<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Taller sobre Codificación de Módulos del Software - GA9-AA1-EV01 | Karen Campo</title>
  <style>
    @page {{
      size: letter;
      margin: 1.8cm 1.6cm 1.8cm 1.6cm;
      @bottom-right {{
        content: counter(page);
      }}
    }}
    * {{
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }}
    body {{
      font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
      color: #1e293b;
      line-height: 1.5;
      font-size: 9.5pt;
      background: #ffffff;
    }}
    .page-break {{
      page-break-before: always;
    }}
    
    /* PORTADA OFICIAL SENA */
    .cover {{
      height: 94vh;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      border: 3px solid #059669;
      padding: 35px 30px;
      background: linear-gradient(180deg, #f0fdf4 0%, #ffffff 100%);
      border-radius: 8px;
    }}
    .cover-header {{
      text-align: center;
      border-bottom: 2px solid #059669;
      padding-bottom: 18px;
    }}
    .cover-header h1 {{
      font-size: 19pt;
      color: #065f46;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-bottom: 6px;
    }}
    .cover-header h2 {{
      font-size: 13pt;
      color: #0f172a;
      font-weight: 600;
    }}
    .cover-header h3 {{
      font-size: 10pt;
      color: #64748b;
      margin-top: 4px;
    }}
    .cover-badge {{
      display: inline-block;
      background: #059669;
      color: white;
      padding: 4px 14px;
      border-radius: 20px;
      font-size: 9pt;
      font-weight: bold;
      margin-top: 10px;
    }}
    .cover-body {{
      text-align: center;
      margin: 20px 0;
    }}
    .cover-title {{
      font-size: 18pt;
      color: #0f172a;
      font-weight: 800;
      line-height: 1.3;
      margin-bottom: 15px;
    }}
    .cover-subtitle {{
      font-size: 11pt;
      color: #334155;
      max-width: 650px;
      margin: 0 auto 20px auto;
      line-height: 1.4;
    }}
    .cover-info-card {{
      background: #ffffff;
      border: 1px solid #cbd5e1;
      border-left: 5px solid #059669;
      border-radius: 6px;
      padding: 15px;
      display: inline-block;
      text-align: left;
      margin: 0 auto;
      min-width: 450px;
    }}
    .cover-info-row {{
      font-size: 9.5pt;
      margin-bottom: 6px;
    }}
    .cover-info-row:last-child {{
      margin-bottom: 0;
    }}
    .cover-info-label {{
      font-weight: bold;
      color: #065f46;
      display: inline-block;
      width: 150px;
    }}
    .cover-footer {{
      text-align: center;
      border-top: 1px solid #cbd5e1;
      padding-top: 15px;
      font-size: 9pt;
      color: #64748b;
    }}

    /* ENCABEZADOS Y TEXTO */
    .header-running {{
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #cbd5e1;
      padding-bottom: 4px;
      margin-bottom: 15px;
      font-size: 8pt;
      color: #64748b;
      text-transform: uppercase;
    }}
    h1.sec-title {{
      font-size: 13pt;
      color: #065f46;
      border-bottom: 2px solid #059669;
      padding-bottom: 4px;
      margin-top: 18px;
      margin-bottom: 10px;
      text-transform: uppercase;
      page-break-after: avoid;
    }}
    h2.subsec-title {{
      font-size: 11pt;
      color: #0f172a;
      margin-top: 12px;
      margin-bottom: 6px;
      border-left: 3px solid #059669;
      padding-left: 8px;
      page-break-after: avoid;
    }}
    p {{
      margin-bottom: 8px;
      text-align: justify;
    }}
    ul, ol {{
      margin-left: 20px;
      margin-bottom: 10px;
    }}
    li {{
      margin-bottom: 4px;
    }}

    /* TABLAS ESTILIZADAS */
    table {{
      width: 100%;
      border-collapse: collapse;
      margin: 12px 0;
      font-size: 8.5pt;
      page-break-inside: avoid;
    }}
    th {{
      background-color: #065f46;
      color: #ffffff;
      padding: 7px 8px;
      text-align: left;
      font-weight: 600;
      border: 1px solid #047857;
    }}
    td {{
      padding: 6px 8px;
      border: 1px solid #cbd5e1;
      vertical-align: top;
    }}
    tr:nth-child(even) {{
      background-color: #f8fafc;
    }}
    .tag-pass {{
      background: #dcfce7;
      color: #15803d;
      padding: 2px 7px;
      border-radius: 4px;
      font-weight: bold;
      font-size: 7.5pt;
    }}

    /* CAJAS DE INFORMACIÓN */
    .callout {{
      background-color: #f0fdf4;
      border: 1px solid #bbf7d0;
      border-left: 4px solid #059669;
      padding: 10px 14px;
      border-radius: 4px;
      margin: 10px 0;
      font-size: 9pt;
    }}
    .callout-title {{
      font-weight: bold;
      color: #065f46;
      margin-bottom: 4px;
    }}

    /* DIAGRAMAS Y CAPTURAS */
    .diagram-container {{
      text-align: center;
      margin: 12px 0;
      page-break-inside: avoid;
    }}
    .diagram-img {{
      max-width: 98%;
      height: auto;
      border: 1px solid #cbd5e1;
      border-radius: 6px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.06);
    }}
    .diagram-caption {{
      font-size: 8pt;
      color: #64748b;
      margin-top: 5px;
      font-style: italic;
    }}
  </style>
</head>
<body>

  <!-- ==================== PORTADA ==================== -->
  <div class="cover">
    <div class="cover-header">
      <h1>Servicio Nacional de Aprendizaje - SENA</h1>
      <h2>Centro de Teleinformática y Producción Industrial (CTPI)</h2>
      <h3>Regional Cauca • Popayán</h3>
      <div class="cover-badge">PROGRAMA ADSO • FICHA 3186681</div>
    </div>

    <div class="cover-body">
      <div class="cover-title">
        TALLER SOBRE CODIFICACIÓN DE MÓDULOS DEL SOFTWARE:<br>
        TESTING, CALIDAD Y VERIFICACIÓN AUTOMATIZADA
      </div>
      <div class="cover-subtitle">
        Desarrollo del cuestionario orientador sobre taxonomía de pruebas de software, adaptación técnica a la solución desacoplada "Pizzería Gourmet Bella Italia Popayán", instalación de herramientas modernas de testing y ejecución de 11 casos de prueba automatizados con métricas y capturas de pantalla.
      </div>

      <div class="cover-info-card">
        <div class="cover-info-row">
          <span class="cover-info-label">Evidencia:</span>
          <strong>GA9-220501096-AA1-EV01</strong>
        </div>
        <div class="cover-info-row">
          <span class="cover-info-label">Competencia:</span>
          <span>220501096 - Desarrollar la solución de software</span>
        </div>
        <div class="cover-info-row">
          <span class="cover-info-label">Aprendiz:</span>
          <strong>Karen Yuliana Campo</strong>
        </div>
        <div class="cover-info-row">
          <span class="cover-info-label">Ficha Formativa:</span>
          <strong>3186681</strong>
        </div>
        <div class="cover-info-row">
          <span class="cover-info-label">Proyecto Formativo:</span>
          <span>Pizzería Gourmet Bella Italia Popayán</span>
        </div>
        <div class="cover-info-row">
          <span class="cover-info-label">Lugar y Fecha:</span>
          <span>Popayán, Cauca — Noviembre 2026</span>
        </div>
      </div>
    </div>

    <div class="cover-footer">
      Tecnología en Análisis y Desarrollo de Software • Modalidad Virtual<br>
      Sistema Integrado de Gestión y Autocontrol (SIGA-SENA)
    </div>
  </div>

  <div class="page-break"></div>

  <!-- ==================== SECCIÓN 1: INTRODUCCIÓN ==================== -->
  <div class="header-running">
    <span>SENA CTPI Popayán • ADSO Ficha 3186681</span>
    <span>GA9-220501096-AA1-EV01: Taller Codificación de Módulos del Software</span>
  </div>

  <h1 class="sec-title">1. INTRODUCCIÓN Y FUNDAMENTACIÓN DE CALIDAD DE SOFTWARE</h1>
  <p>
    En la ingeniería de software actual, el aseguramiento de calidad (**Software Quality Assurance - SQA**) y las pruebas (**Software Testing**) han dejado de ser actividades tardías para convertirse en disciplinas transversales indispensables. El estándar internacional <strong>ISO/IEC/IEEE 29119</strong> define el testing como un proceso sistemático para evaluar atributos de funcionalidad, confiabilidad, seguridad y rendimiento, facilitando la detección precoz de anomalías (<strong>bugs</strong>).
  </p>
  <p>
    El costo de corregir un defecto detectado en producción es hasta <strong>30 veces superior</strong> al costo de resolverlo durante la fase de desarrollo unitario. Por ello, enfoques modernos como el Desarrollo Guiado por Pruebas (<strong>Test-Driven Development - TDD</strong>) establecen que la codificación de pruebas automáticas debe anteceder o acompañar la construcción de cada módulo funcional.
  </p>

  <h1 class="sec-title">2. PREGUNTA 1: ¿QUÉ TIPOS DE PRUEBAS DE SOFTWARE EXISTEN?</h1>
  <p>
    La taxonomía del testing clasifica las pruebas según múltiples dimensiones técnicas y operativas:
  </p>

  <h2 class="subsec-title">2.1. Clasificación por Nivel de Granularidad (Pirámide de Pruebas de Mike Cohn)</h2>
  <ul>
    <li><strong>Pruebas Unitarias (Unit Testing):</strong> Validan la unidad mínima de código verificable (funciones, métodos o clases) de forma aislada, empleando simuladores (mocks o stubs). Son ultrarrápidas y aportan retroalimentación inmediata al desarrollador.</li>
    <li><strong>Pruebas de Integración (Integration Testing):</strong> Evalúan la interacción entre módulos acoplados, validando flujos de datos entre APIs RESTful, bases de datos (MongoDB / MariaDB) y servicios externos.</li>
    <li><strong>Pruebas de Sistema (System Testing):</strong> Validan el sistema completo e integrado como un todo unificado, verificando el cumplimiento de especificaciones en entornos pre-productivos.</li>
    <li><strong>Pruebas de Aceptación (UAT):</strong> Conducidas por usuarios finales y especialistas de negocio para certificar que el producto satisface los criterios de aceptación y casos de uso requeridos.</li>
  </ul>

  <h2 class="subsec-title">2.2. Clasificación por Conocimiento del Código y Objetivos</h2>
  <table>
    <thead>
      <tr>
        <th style="width: 25%;">Tipo de Prueba</th>
        <th style="width: 45%;">Características Principales</th>
        <th style="width: 30%;">Beneficios para el Software</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><strong>Caja Blanca (White-Box)</strong></td>
        <td>Conocimiento exhaustivo del código fuente; evalúa cobertura de ramas, ciclos y condiciones lógicas internas.</td>
        <td>Detección de código muerto, fugas de memoria y optimización de complejidad ciclomática.</td>
      </tr>
      <tr>
        <td><strong>Caja Negra (Black-Box)</strong></td>
        <td>Sin conocimiento del código interno; evalúa salidas esperadas frente a entradas según especificaciones funcionales.</td>
        <td>Valida la experiencia real de usuario y detecta inconsistencias con requerimientos.</td>
      </tr>
      <tr>
        <td><strong>Pruebas de Regresión</strong></td>
        <td>Re-ejecución automática de baterías de prueba tras cada cambio en el repositorio.</td>
        <td>Garantiza que nuevas funcionalidades no rompan módulos estabilizados previamente.</td>
      </tr>
      <tr>
        <td><strong>Pruebas de Seguridad (OWASP)</strong></td>
        <td>Búsqueda de vulnerabilidades (inyección SQL/NoSQL, XSS, autenticación rota, tokens expirados).</td>
        <td>Protege la confidencialidad de datos de clientes y previene secuestro de sesiones.</td>
      </tr>
      <tr>
        <td><strong>Pruebas de Carga y Rendimiento</strong></td>
        <td>Medición de latencia y consumo de recursos bajo tráfico concurrente elevado.</td>
        <td>Asegura alta disponibilidad y tiempos de respuesta &lt; 200 ms en picos de demanda.</td>
      </tr>
    </tbody>
  </table>

  <div class="page-break"></div>

  <!-- ==================== SECCIÓN 3: ADAPTACIÓN AL PROYECTO ==================== -->
  <div class="header-running">
    <span>SENA CTPI Popayán • ADSO Ficha 3186681</span>
    <span>GA9-220501096-AA1-EV01: Taller Codificación de Módulos del Software</span>
  </div>

  <h1 class="sec-title">3. PREGUNTA 2: TIPOS DE PRUEBAS ADAPTADAS AL PROYECTO "BELLA ITALIA POPAYÁN"</h1>
  <p>
    La solución de software de la <strong>Pizzería Gourmet Bella Italia Popayán</strong> cuenta con una arquitectura desacoplada en microservicios backend en <strong>Go (Fiber v2)</strong> y <strong>Node.js</strong> con bases de datos <strong>MongoDB</strong> y <strong>MariaDB</strong>, frontend web en <strong>React/Vite</strong> y app móvil en <strong>React Native</strong>. Para este entorno se priorizan 5 tipos de pruebas:
  </p>

  <div class="callout">
    <div class="callout-title">Los 5 Pilares de Testing en la Pizzería Gourmet Bella Italia</div>
    <ul style="margin-bottom: 0;">
      <li><strong>1. Pruebas Unitarias de Lógica de Negocio y Facturación:</strong> Validación del cálculo de subtotales, costo de envío zonal en Popayán, cupones promocionales y el <strong>Impoconsumo del 8%</strong> obligatorio en Colombia (Estatuto Tributario).</li>
      <li><strong>2. Pruebas de Integración de Endpoints RESTful:</strong> Verificación de contratos JSON, códigos de estado HTTP (200 OK, 201 Created, 400 Bad Request) y persistencia de comandas.</li>
      <li><strong>3. Pruebas de Seguridad y Control de Acceso RBAC:</strong> Validación de contraseñas robustas, tokens JWT y jerarquía de permisos entre roles (Admin, Cocinero, Repartidor, Cliente).</li>
      <li><strong>4. Pruebas de Saneamiento contra Ataques Web:</strong> Filtrado y escape de caracteres para neutralizar inyecciones Cross-Site Scripting (XSS) y NoSQL Injection en MongoDB.</li>
      <li><strong>5. Pruebas de Regresión Automatizadas en CI/CD:</strong> Ejecución de baterías de pruebas en contenedores Docker antes de cada despliegue para garantizar cero defectos residuales.</li>
    </ul>
  </div>

  <h1 class="sec-title">4. PREGUNTA 3: HERRAMIENTAS DE PRUEBA INVESTIGADAS E INSTALADAS</h1>
  <p>
    Se evaluaron herramientas líderes de la industria (Jest, Vitest, Go test, Postman y k6). Como herramienta principal de trabajo se seleccionó e instaló el <strong>Node.js Native Test Runner (<code>node:test</code>)</strong> junto con la biblioteca <strong><code>node:assert/strict</code></strong> y <strong>Newman (Postman CLI)</strong>:
  </p>

  <!-- CAPTURA 1 -->
  <div class="diagram-container">
    <img src="file://{cap1_path}" alt="Instalación y Configuración de Herramientas de Testing" class="diagram-img">
    <div class="diagram-caption">Figura 1: Verificación de versiones de Node.js v20 LTS, npm, Docker y configuración del motor de pruebas unitarias.</div>
  </div>

  <p>
    <strong>Ventajas Clave de la Herramienta Seleccionada:</strong>
    1) Integrada de forma nativa en Node.js 20 LTS sin requerir pesados transpileres Babel ni cientos de megabytes en paquetes externos;
    2) Soporta el protocolo estándar TAP (Test Anything Protocol);
    3) Tiempos de ejecución instantáneos (inferiores a 200 ms para la suite completa), ideal para pipelines ágiles de integración continua.
  </p>

  <div class="page-break"></div>

  <!-- ==================== SECCIÓN 5: EJECUCIÓN Y CAPTURAS ==================== -->
  <div class="header-running">
    <span>SENA CTPI Popayán • ADSO Ficha 3186681</span>
    <span>GA9-220501096-AA1-EV01: Taller Codificación de Módulos del Software</span>
  </div>

  <h1 class="sec-title">5. PREGUNTA 4: EJECUCIÓN DE PRUEBAS DE LA SOLUCIÓN DE SOFTWARE</h1>
  <p>
    Se desarrolló y ejecutó la suite de pruebas automatizadas en el archivo <code>pruebas/pizzeria_modules_testing.js</code>, evaluando los 4 módulos operativos más sensibles de la pizzería a través de <strong>11 casos de prueba formales</strong>:
  </p>

  <!-- CAPTURA 2 -->
  <div class="diagram-container">
    <img src="file://{cap2_path}" alt="Ejecución de Pruebas de Módulos en Terminal" class="diagram-img">
    <div class="diagram-caption">Figura 2: Consola de ejecución del motor de pruebas reflejando la aprobación exitosa del 100% de los 11 casos de prueba en 156.71 ms.</div>
  </div>

  <!-- CAPTURA 3 -->
  <div class="diagram-container">
    <img src="file://{cap3_path}" alt="Dashboard de Resultados y Métricas de Calidad" class="diagram-img">
    <div class="diagram-caption">Figura 3: Panel consolidado de control de calidad (SQA) con métricas de aserción, tiempos de ejecución y estado de cada módulo.</div>
  </div>

  <div class="page-break"></div>

  <!-- ==================== SECCIÓN 6: RESUMEN ANALÍTICO ==================== -->
  <div class="header-running">
    <span>SENA CTPI Popayán • ADSO Ficha 3186681</span>
    <span>GA9-220501096-AA1-EV01: Taller Codificación de Módulos del Software</span>
  </div>

  <h1 class="sec-title">6. PREGUNTA 5: RESUMEN ANALÍTICO DE LAS PRUEBAS REALIZADAS</h1>
  <p>
    A continuación se presenta la matriz detallada con la totalidad de los 11 casos de prueba ejecutados sobre los módulos de software del proyecto formativo:
  </p>

  <table>
    <thead>
      <tr>
        <th style="width: 8%;">ID</th>
        <th style="width: 20%;">Módulo Evaluado</th>
        <th style="width: 32%;">Descripción del Caso de Prueba</th>
        <th style="width: 25%;">Criterio de Aserción / Resultado</th>
        <th style="width: 8%;">Tiempo</th>
        <th style="width: 7%;">Estado</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><strong>CP01</strong></td>
        <td>Cálculo Pedidos</td>
        <td>Subtotal, Impoconsumo del 8% y envío Popayán Centro</td>
        <td>Total exacto de $61.320 COP (Impuesto $4.320)</td>
        <td>3.2 ms</td>
        <td><span class="tag-pass">PASÓ</span></td>
      </tr>
      <tr>
        <td><strong>CP02</strong></td>
        <td>Cálculo Pedidos</td>
        <td>Envío gratuito para órdenes &gt;= $60.000 COP</td>
        <td>Costo de envío = $0 COP verificado</td>
        <td>0.3 ms</td>
        <td><span class="tag-pass">PASÓ</span></td>
      </tr>
      <tr>
        <td><strong>CP03</strong></td>
        <td>Cálculo Pedidos</td>
        <td>Aplicación de cupón Gourmet BELLAITALIA10 (10%)</td>
        <td>Descuento exacto de $4.000 COP sobre subtotal</td>
        <td>0.2 ms</td>
        <td><span class="tag-pass">PASÓ</span></td>
      </tr>
      <tr>
        <td><strong>CP04</strong></td>
        <td>Cálculo Pedidos</td>
        <td>Control de excepciones ante listas vacías de productos</td>
        <td>Excepción capturada: "Al menos un producto"</td>
        <td>0.6 ms</td>
        <td><span class="tag-pass">PASÓ</span></td>
      </tr>
      <tr>
        <td><strong>CP05</strong></td>
        <td>Seguridad / Auth</td>
        <td>Complejidad de contraseña (Mayus, Num, Simb, &ge;8)</td>
        <td>Acepta 'BellaItalia2026!' y rechaza 'debil'</td>
        <td>0.5 ms</td>
        <td><span class="tag-pass">PASÓ</span></td>
      </tr>
      <tr>
        <td><strong>CP06</strong></td>
        <td>Seguridad / Auth</td>
        <td>Validación de formato sintáctico de email</td>
        <td>Valida correos canónicos y bloquea malformados</td>
        <td>0.4 ms</td>
        <td><span class="tag-pass">PASÓ</span></td>
      </tr>
      <tr>
        <td><strong>CP07</strong></td>
        <td>Seguridad / RBAC</td>
        <td>Jerarquía de roles (ADMIN &gt; COCINERO &gt; REPARTIDOR &gt; CLIENTE)</td>
        <td>Bloqueo estricto de accesos no autorizados</td>
        <td>0.3 ms</td>
        <td><span class="tag-pass">PASÓ</span></td>
      </tr>
      <tr>
        <td><strong>CP08</strong></td>
        <td>Clientes</td>
        <td>Validación de celular colombiano (10 dígitos inicia en 3)</td>
        <td>Acepta '3127894561' y rechaza números fijos</td>
        <td>0.8 ms</td>
        <td><span class="tag-pass">PASÓ</span></td>
      </tr>
      <tr>
        <td><strong>CP09</strong></td>
        <td>Seguridad / Web</td>
        <td>Saneamiento de texto contra ataques XSS y NoSQL</td>
        <td>Escape de caracteres peligrosos &lt;, &gt;, &quot;, &#x27;, $</td>
        <td>0.5 ms</td>
        <td><span class="tag-pass">PASÓ</span></td>
      </tr>
      <tr>
        <td><strong>CP10</strong></td>
        <td>Inventario</td>
        <td>Reserva de insumos de receta (harina, queso, pomodoro)</td>
        <td>Descuento exacto de stock en gramos</td>
        <td>0.7 ms</td>
        <td><span class="tag-pass">PASÓ</span></td>
      </tr>
      <tr>
        <td><strong>CP11</strong></td>
        <td>Inventario</td>
        <td>Bloqueo transaccional ante desabastecimiento de bodega</td>
        <td>Excepción capturada: "Stock insuficiente"</td>
        <td>0.3 ms</td>
        <td><span class="tag-pass">PASÓ</span></td>
      </tr>
    </tbody>
  </table>

  <h1 class="sec-title">7. CONCLUSIONES</h1>
  <ol>
    <li><strong>El Testing como Salvaguarda de Negocio:</strong> Las pruebas de software automatizadas no representan un sobrecosto, sino la inversión de ingeniería más costo-efectiva para prevenir fallos catastróficos y garantizar la estabilidad transaccional de la solución informática.</li>
    <li><strong>Efectividad del Motor Nativo Node.js:</strong> El uso del motor <code>node:test</code> permitió ejecutar la totalidad de los 11 casos de prueba en tan solo <strong>156.71 milisegundos</strong>, logrando un 100% de aprobación con cero defectos críticos.</li>
    <li><strong>Consolidación del Perfil ADSO:</strong> Para la aprendiz Karen Campo, este taller afianza las competencias indispensables para diseñar suites de pruebas sistemáticas y reproducibles bajo estándares internacionales.</li>
  </ol>

  <h1 class="sec-title">8. REFERENCIAS BIBLIOGRÁFICAS (NORMAS APA 7MA EDICIÓN)</h1>
  <ul style="list-style-type: none; margin-left: 0;">
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Cohn, M. (2009). <em>Succeeding with Agile: Software Development Using Scrum</em>. Addison-Wesley Professional.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      International Organization for Standardization. (2013). <em>ISO/IEC/IEEE 29119-1: Software and systems engineering — Software testing</em>. ISO.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Node.js Foundation. (2024). <em>Node.js v20.x Documentation: Test runner module (node:test)</em>. https://nodejs.org/api/test.html
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Open Web Application Security Project - OWASP. (2021). <em>OWASP Top 10: The Ten Most Critical Web Application Security Risks</em>. OWASP Foundation.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Postman Inc. (2024). <em>Newman: The command-line collection runner for Postman</em>. Postman Documentation.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Pressman, R. S., & Maxim, B. R. (2020). <em>Software Engineering: A Practitioner's Approach</em> (9th ed.). McGraw-Hill Education.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Servicio Nacional de Aprendizaje - SENA. (2026). <em>Componente Formativo: Las pruebas de software</em>. Dirección de Formación Profesional.
    </li>
  </ul>

</body>
</html>
"""

html_file_path = os.path.join(DOCS_DIR, 'reporte_imprimible.html')
with open(html_file_path, 'w', encoding='utf-8') as f:
    f.write(html_content)
print(f"HTML generado en: {html_file_path}")

# Compilar PDF formal usando Google Chrome Headless
pdf_filename = 'GA9-220501096-AA1-EV01_Taller_Codificacion_Modulos_Pruebas.pdf'
pdf_output_path = os.path.join(DOCS_DIR, pdf_filename)
pdf_entrega_path = os.path.join(ENTREGA_DIR, pdf_filename)

chrome_cmd = [
    'google-chrome',
    '--headless',
    '--disable-gpu',
    '--no-pdf-header-footer',
    f'--print-to-pdf={pdf_output_path}',
    html_file_path
]

print("Compilando PDF institucional con Google Chrome...")
res_chrome = subprocess.run(chrome_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
if res_chrome.returncode == 0 and os.path.exists(pdf_output_path):
    pdf_size_kb = os.path.getsize(pdf_output_path) / 1024
    print(f"PDF generado exitosamente ({pdf_size_kb:.1f} KB) en: {pdf_output_path}")
    shutil.copy2(pdf_output_path, pdf_entrega_path)
    print(f"PDF copiado a entrega Zajuna: {pdf_entrega_path}")
else:
    print(f"Error al generar PDF: {res_chrome.stderr.decode()}")

# Compilar Formato Word (DOCX) con LibreOffice Headless
docx_filename = 'GA9-220501096-AA1-EV01_Taller_Codificacion_Modulos_Pruebas.docx'
docx_output_path = os.path.join(DOCS_DIR, docx_filename)
docx_entrega_path = os.path.join(ENTREGA_DIR, docx_filename)

libreoffice_cmd = [
    'libreoffice',
    '--headless',
    '--convert-to',
    'docx:MS Word 2007 XML',
    html_file_path,
    '--outdir',
    DOCS_DIR
]

print("Compilando formato Word (DOCX) con LibreOffice...")
res_lo = subprocess.run(libreoffice_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
generated_docx = os.path.join(DOCS_DIR, 'reporte_imprimible.docx')
if os.path.exists(generated_docx):
    if os.path.exists(docx_output_path):
        os.remove(docx_output_path)
    os.rename(generated_docx, docx_output_path)
    docx_size_kb = os.path.getsize(docx_output_path) / 1024
    print(f"DOCX generado exitosamente ({docx_size_kb:.1f} KB) en: {docx_output_path}")
    shutil.copy2(docx_output_path, docx_entrega_path)
    print(f"DOCX copiado a entrega Zajuna: {docx_entrega_path}")
