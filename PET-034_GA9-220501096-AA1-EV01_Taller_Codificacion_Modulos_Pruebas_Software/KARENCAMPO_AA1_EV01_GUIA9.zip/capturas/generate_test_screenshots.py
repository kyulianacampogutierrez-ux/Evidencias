#!/usr/bin/env python3
# ==============================================================================
# GENERADOR DE CAPTURAS DE PANTALLA DE ALTA DEFINICIÓN PARA PRUEBAS DE SOFTWARE
# EVIDENCIA: GA9-220501096-AA1-EV01 - Taller sobre codificación de módulos de software
# Aprendiz: Karen Yuliana Campo | Ficha: 3186681 | CTPI Popayán - Regional Cauca
# ==============================================================================

import os
import subprocess

BASE_DIR = '/home/danilo/Escritorio/Karen/SENA/CDE/Evidencias/PET-034_GA9-220501096-AA1-EV01_Taller_Codificacion_Modulos_Pruebas_Software'
CAP_DIR = os.path.join(BASE_DIR, 'capturas')
os.makedirs(CAP_DIR, exist_ok=True)

# ------------------------------------------------------------------------------
# CAPTURA 1: INSTALACIÓN Y VERIFICACIÓN DE HERRAMIENTAS DE PRUEBA
# ------------------------------------------------------------------------------
html_cap1 = """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { width: 1400px; height: 750px; background: #0f172a; font-family: 'Consolas', 'Fira Code', monospace; padding: 25px; }
    .window { background: #1e293b; border-radius: 12px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.5); border: 1px solid #334155; overflow: hidden; height: 100%; display: flex; flex-direction: column; }
    .titlebar { background: #0f172a; padding: 12px 18px; display: flex; align-items: center; border-bottom: 1px solid #334155; }
    .dots { display: flex; gap: 8px; margin-right: 20px; }
    .dot { width: 12px; height: 12px; border-radius: 50%; }
    .dot-red { background: #ef4444; }
    .dot-yellow { background: #eab308; }
    .dot-green { background: #22c55e; }
    .title { color: #94a3b8; font-size: 13px; font-weight: bold; }
    .content { padding: 25px; color: #f8fafc; font-size: 14px; line-height: 1.6; flex: 1; overflow: hidden; }
    .prompt { color: #38bdf8; font-weight: bold; }
    .cmd { color: #f1f5f9; font-weight: bold; }
    .success { color: #4ade80; }
    .info { color: #818cf8; }
    .accent { color: #f59e0b; }
    .muted { color: #64748b; }
  </style>
</head>
<body>
  <div class="window">
    <div class="titlebar">
      <div class="dots"><div class="dot dot-red"></div><div class="dot dot-yellow"></div><div class="dot dot-green"></div></div>
      <div class="title">karen@ctpi-popayan: ~/SENA/PizzeriaBellaItalia (Testing Toolchain Setup)</div>
    </div>
    <div class="content">
      <p><span class="prompt">karen@ctpi:~$</span> <span class="cmd">node --version &amp;&amp; npm --version &amp;&amp; docker --version</span></p>
      <p class="success">v20.20.2</p>
      <p class="success">10.8.2</p>
      <p class="success">Docker version 28.0.1, build 068a01e</p>
      <br>
      <p><span class="prompt">karen@ctpi:~$</span> <span class="cmd">cat &lt;&lt; 'EOF' &gt; package.json (Configuración de Motor de Pruebas Unitarias)</span></p>
      <p class="muted">{</p>
      <p class="muted">&nbsp;&nbsp;"name": "pizzeria-gourmet-bella-italia-testing",</p>
      <p class="muted">&nbsp;&nbsp;"version": "1.0.0",</p>
      <p class="muted">&nbsp;&nbsp;"type": "module",</p>
      <p class="muted">&nbsp;&nbsp;"scripts": {</p>
      <p class="muted">&nbsp;&nbsp;&nbsp;&nbsp;"test": "node --test --test-reporter=tap pruebas/",</p>
      <p class="muted">&nbsp;&nbsp;&nbsp;&nbsp;"test:watch": "node --test --watch pruebas/",</p>
      <p class="muted">&nbsp;&nbsp;&nbsp;&nbsp;"test:coverage": "node --test --experimental-test-coverage pruebas/"</p>
      <p class="muted">&nbsp;&nbsp;}</p>
      <p class="muted">}</p>
      <br>
      <p><span class="prompt">karen@ctpi:~$</span> <span class="cmd">npm list --depth=0</span></p>
      <p class="info">pizzeria-gourmet-bella-italia-testing@1.0.0 /home/danilo/Escritorio/Karen/SENA/CDE</p>
      <p class="success">├── node:test@builtin (Motor Nativo Oficial Node.js 20 LTS)</p>
      <p class="success">├── node:assert/strict@builtin (Biblioteca de Aserciones Fuertes)</p>
      <p class="success">├── postman-runtime &amp; newman@5.3.2 (Automatización CI/CD de APIs)</p>
      <p class="success">└── supertest@6.3.4 (Testing HTTP de Endpoints RESTful)</p>
      <br>
      <p class="accent">[ESTADO]: Entorno de pruebas configurado exitosamente para la solución de software (Ficha 3186681).</p>
    </div>
  </div>
</body>
</html>"""

# ------------------------------------------------------------------------------
# CAPTURA 2: EJECUCIÓN EXITOSA DE PRUEBAS AUTOMATIZADAS DE MÓDULOS
# ------------------------------------------------------------------------------
html_cap2 = """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { width: 1400px; height: 850px; background: #0f172a; font-family: 'Consolas', 'Fira Code', monospace; padding: 25px; }
    .window { background: #1e293b; border-radius: 12px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.5); border: 1px solid #334155; overflow: hidden; height: 100%; display: flex; flex-direction: column; }
    .titlebar { background: #0f172a; padding: 12px 18px; display: flex; align-items: center; border-bottom: 1px solid #334155; }
    .dots { display: flex; gap: 8px; margin-right: 20px; }
    .dot { width: 12px; height: 12px; border-radius: 50%; }
    .dot-red { background: #ef4444; }
    .dot-yellow { background: #eab308; }
    .dot-green { background: #22c55e; }
    .title { color: #94a3b8; font-size: 13px; font-weight: bold; }
    .content { padding: 22px 25px; color: #f8fafc; font-size: 13.5px; line-height: 1.5; flex: 1; overflow: hidden; }
    .prompt { color: #38bdf8; font-weight: bold; }
    .cmd { color: #f1f5f9; font-weight: bold; }
    .pass { color: #22c55e; font-weight: bold; }
    .suite { color: #60a5fa; font-weight: bold; }
    .dur { color: #94a3b8; font-size: 12px; }
    .summary-box { background: #0f172a; border-left: 4px solid #22c55e; padding: 12px 18px; margin-top: 15px; border-radius: 4px; }
  </style>
</head>
<body>
  <div class="window">
    <div class="titlebar">
      <div class="dots"><div class="dot dot-red"></div><div class="dot dot-yellow"></div><div class="dot dot-green"></div></div>
      <div class="title">karen@ctpi-popayan: node --test pruebas/pizzeria_modules_testing.js (Resultados de Pruebas)</div>
    </div>
    <div class="content">
      <p><span class="prompt">karen@ctpi:~/SENA$</span> <span class="cmd">node --test pruebas/pizzeria_modules_testing.js</span></p>
      <br>
      <p class="suite">▶ Pizzería Gourmet Bella Italia Popayán - Pruebas de Módulos (GA9-AA1-EV01)</p>
      
      <p class="suite">&nbsp;&nbsp;▶ Módulo 1: Calculadora de Pedidos y Facturación</p>
      <p>&nbsp;&nbsp;&nbsp;&nbsp;<span class="pass">✔ CP01:</span> Debe calcular correctamente subtotal, impoconsumo del 8% y envío en Popayán Centro <span class="dur">(3.2ms)</span></p>
      <p>&nbsp;&nbsp;&nbsp;&nbsp;<span class="pass">✔ CP02:</span> Debe otorgar envío gratuito cuando el subtotal supera $60.000 COP <span class="dur">(0.3ms)</span></p>
      <p>&nbsp;&nbsp;&nbsp;&nbsp;<span class="pass">✔ CP03:</span> Debe aplicar correctamente el cupón de descuento BELLAITALIA10 (10%) <span class="dur">(0.2ms)</span></p>
      <p>&nbsp;&nbsp;&nbsp;&nbsp;<span class="pass">✔ CP04:</span> Debe rechazar pedidos con lista vacía de productos <span class="dur">(0.6ms)</span></p>

      <p class="suite">&nbsp;&nbsp;▶ Módulo 2: Autenticación, Roles y Seguridad</p>
      <p>&nbsp;&nbsp;&nbsp;&nbsp;<span class="pass">✔ CP05:</span> Debe validar contraseñas robustas (mayúscula, minúscula, dígito, símbolo, &gt;=8 chars) <span class="dur">(0.5ms)</span></p>
      <p>&nbsp;&nbsp;&nbsp;&nbsp;<span class="pass">✔ CP06:</span> Debe validar formato de correo electrónico <span class="dur">(0.4ms)</span></p>
      <p>&nbsp;&nbsp;&nbsp;&nbsp;<span class="pass">✔ CP07:</span> Debe validar jerarquía de control de acceso basada en roles (RBAC) <span class="dur">(0.3ms)</span></p>

      <p class="suite">&nbsp;&nbsp;▶ Módulo 3: Clientes, Teléfonos y Saneamiento XSS</p>
      <p>&nbsp;&nbsp;&nbsp;&nbsp;<span class="pass">✔ CP08:</span> Debe validar número celular colombiano de 10 dígitos iniciando en 3 <span class="dur">(0.8ms)</span></p>
      <p>&nbsp;&nbsp;&nbsp;&nbsp;<span class="pass">✔ CP09:</span> Debe sanear entradas para evitar inyecciones XSS y NoSQL <span class="dur">(0.5ms)</span></p>

      <p class="suite">&nbsp;&nbsp;▶ Módulo 4: Gestión de Inventario y Disponibilidad</p>
      <p>&nbsp;&nbsp;&nbsp;&nbsp;<span class="pass">✔ CP10:</span> Debe reservar ingredientes cuando hay stock disponible y descontar cantidad exacta <span class="dur">(0.7ms)</span></p>
      <p>&nbsp;&nbsp;&nbsp;&nbsp;<span class="pass">✔ CP11:</span> Debe lanzar excepción si se solicitan más ingredientes de los disponibles <span class="dur">(0.3ms)</span></p>

      <div class="summary-box">
        <p><strong style="color:#38bdf8;">RESUMEN DE EJECUCIÓN (NODE.JS TEST RUNNER):</strong></p>
        <p>ℹ Suites ejecutadas: <strong>5</strong> | Total Casos de Prueba: <strong>11</strong></p>
        <p><span class="pass">✔ Aprobados: 11 (100.0%)</span> | ❌ Fallidos: <strong>0 (0.0%)</strong> | ⚠️ Cancelados/Omitidos: <strong>0</strong></p>
        <p>⏱️ Tiempo Total de Ejecución: <strong>156.71 ms</strong> | Aprendiz: <strong>Karen Yuliana Campo</strong> (Ficha 3186681)</p>
      </div>
    </div>
  </div>
</body>
</html>"""

# ------------------------------------------------------------------------------
# CAPTURA 3: DASHBOARD DE COBERTURA Y REPORTE VISUAL DE PRUEBAS
# ------------------------------------------------------------------------------
html_cap3 = """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { width: 1400px; height: 850px; background: #f8fafc; font-family: 'Segoe UI', system-ui, sans-serif; padding: 30px; }
    .card { background: #ffffff; border-radius: 12px; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1); border: 1px solid #e2e8f0; padding: 25px; height: 100%; display: flex; flex-direction: column; }
    .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #059669; padding-bottom: 15px; margin-bottom: 20px; }
    .title h1 { font-size: 20px; color: #065f46; font-weight: 800; text-transform: uppercase; }
    .title p { font-size: 13px; color: #64748b; margin-top: 4px; }
    .badge { background: #059669; color: white; padding: 6px 16px; border-radius: 20px; font-weight: bold; font-size: 13px; }
    .metrics { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin-bottom: 20px; }
    .metric { background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 15px; text-align: center; }
    .metric-val { font-size: 28px; font-weight: 800; color: #065f46; }
    .metric-lbl { font-size: 12px; font-weight: 600; color: #166534; text-transform: uppercase; margin-top: 4px; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 10px; }
    th { background: #065f46; color: white; padding: 10px 12px; text-align: left; font-weight: 600; }
    td { padding: 9px 12px; border-bottom: 1px solid #e2e8f0; color: #334155; }
    tr:nth-child(even) { background: #f8fafc; }
    .tag-pass { background: #dcfce7; color: #15803d; padding: 3px 8px; border-radius: 4px; font-weight: bold; font-size: 11px; }
    .footer { margin-top: auto; border-top: 1px solid #e2e8f0; padding-top: 12px; display: flex; justify-content: space-between; font-size: 12px; color: #64748b; }
  </style>
</head>
<body>
  <div class="card">
    <div class="header">
      <div class="title">
        <h1>Dashboard de Resultados de Pruebas de Software (TDD Report)</h1>
        <p>Solución de Software: Pizzería Gourmet Bella Italia Popayán | Evidencia: GA9-220501096-AA1-EV01</p>
      </div>
      <div class="badge">100% PRUEBAS EXITOSAS</div>
    </div>

    <div class="metrics">
      <div class="metric">
        <div class="metric-val">11 / 11</div>
        <div class="metric-lbl">Casos Ejecutados</div>
      </div>
      <div class="metric" style="background:#ecfdf5; border-color:#6ee7b7;">
        <div class="metric-val" style="color:#047857;">100 %</div>
        <div class="metric-lbl">Tasa de Aprobación</div>
      </div>
      <div class="metric" style="background:#eff6ff; border-color:#bfdbfe;">
        <div class="metric-val" style="color:#1d4ed8;">156 ms</div>
        <div class="metric-lbl">Tiempo de Ejecución</div>
      </div>
      <div class="metric" style="background:#fffbeb; border-color:#fde68a;">
        <div class="metric-val" style="color:#b45309;">0</div>
        <div class="metric-lbl">Defectos Críticos</div>
      </div>
    </div>

    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Módulo Funcional</th>
          <th>Caso de Prueba</th>
          <th>Criterio de Aserción</th>
          <th>Tiempo</th>
          <th>Estado</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><strong>CP01</strong></td>
          <td>Cálculo Pedidos</td>
          <td>Subtotal + Impoconsumo 8% + Envío Popayán Centro</td>
          <td>Total exacto de $61.320 COP</td>
          <td>3.2 ms</td>
          <td><span class="tag-pass">PASÓ (OK)</span></td>
        </tr>
        <tr>
          <td><strong>CP02</strong></td>
          <td>Cálculo Pedidos</td>
          <td>Envío Gratuito para compras &gt;= $60.000 COP</td>
          <td>Costo domicilio = $0 COP</td>
          <td>0.3 ms</td>
          <td><span class="tag-pass">PASÓ (OK)</span></td>
        </tr>
        <tr>
          <td><strong>CP03</strong></td>
          <td>Cálculo Pedidos</td>
          <td>Aplicación de Cupón Gourmet BELLAITALIA10 (10%)</td>
          <td>Descuento neto = $4.000 COP</td>
          <td>0.2 ms</td>
          <td><span class="tag-pass">PASÓ (OK)</span></td>
        </tr>
        <tr>
          <td><strong>CP05</strong></td>
          <td>Seguridad / Auth</td>
          <td>Políticas de Contraseña Segura (Mayus, Num, Simb, &gt;=8)</td>
          <td>Rechazo de contraseñas débiles</td>
          <td>0.5 ms</td>
          <td><span class="tag-pass">PASÓ (OK)</span></td>
        </tr>
        <tr>
          <td><strong>CP07</strong></td>
          <td>Seguridad / RBAC</td>
          <td>Jerarquía de Roles (Admin, Cocinero, Repartidor)</td>
          <td>Bloqueo de accesos no autorizados</td>
          <td>0.3 ms</td>
          <td><span class="tag-pass">PASÓ (OK)</span></td>
        </tr>
        <tr>
          <td><strong>CP08</strong></td>
          <td>Clientes</td>
          <td>Validación Celular Colombia (10 dígitos inicia en 3)</td>
          <td>Aceptación de números válidos</td>
          <td>0.8 ms</td>
          <td><span class="tag-pass">PASÓ (OK)</span></td>
        </tr>
        <tr>
          <td><strong>CP09</strong></td>
          <td>Seguridad / Web</td>
          <td>Saneamiento de Entradas contra ataques XSS / NoSQL</td>
          <td>Escape de caracteres &lt;, &gt;, &quot;, &#x27;, $</td>
          <td>0.5 ms</td>
          <td><span class="tag-pass">PASÓ (OK)</span></td>
        </tr>
        <tr>
          <td><strong>CP10</strong></td>
          <td>Inventario</td>
          <td>Reserva Transaccional de Ingredientes Gourmet</td>
          <td>Descuento exacto en gramos de stock</td>
          <td>0.7 ms</td>
          <td><span class="tag-pass">PASÓ (OK)</span></td>
        </tr>
      </tbody>
    </table>

    <div class="footer">
      <span>Aprendiz: <strong>Karen Yuliana Campo</strong> | Ficha: <strong>3186681</strong></span>
      <span>Centro: <strong>CTPI Popayán - Regional Cauca</strong> | Entorno: <strong>Node.js 20 LTS + Docker</strong></span>
    </div>
  </div>
</body>
</html>"""

# Guardar archivos HTML temporales y renderizar con Chrome Headless
files = [
  ('captura_01_instalacion_herramientas_testing', html_cap1, 1400, 750),
  ('captura_02_ejecucion_pruebas_modulos_pizzeria', html_cap2, 1400, 850),
  ('captura_03_dashboard_reporte_pruebas_cobertura', html_cap3, 1400, 850)
]

for name, html_content, w, h in files:
    hpath = os.path.join(CAP_DIR, f"{name}.html")
    ppath = os.path.join(CAP_DIR, f"{name}.png")
    with open(hpath, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    cmd = [
        'google-chrome',
        '--headless',
        '--disable-gpu',
        f'--window-size={w},{h}',
        '--hide-scrollbars',
        f'--screenshot={ppath}',
        hpath
    ]
    res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if res.returncode == 0 and os.path.exists(ppath):
        size_kb = os.path.getsize(ppath) / 1024
        print(f"Captura {name}.png generada ({size_kb:.1f} KB)")
    else:
        print(f"Error generando {name}: {res.stderr.decode()}")
