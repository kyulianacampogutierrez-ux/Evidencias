package com.sena.pizzeria;

import com.sena.pizzeria.dto.ItemPedidoDTO;
import com.sena.pizzeria.dto.PedidoRequestDTO;
import com.sena.pizzeria.entity.Cliente;
import com.sena.pizzeria.entity.Pedido;
import com.sena.pizzeria.entity.Pizza;
import com.sena.pizzeria.repository.ClienteRepository;
import com.sena.pizzeria.repository.PedidoRepository;
import com.sena.pizzeria.repository.PizzaRepository;
import com.sena.pizzeria.service.ClienteService;
import com.sena.pizzeria.service.PedidoService;
import com.sena.pizzeria.service.PizzaService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Pruebas unitarias para los servicios Spring Boot de la Pizzería Bella Italia.
 * Evidencia: GA7-220501096-AA3-EV01
 * 
 * @author Karen Yuliana Campo
 */
@ExtendWith(MockitoExtension.class)
public class PizzeriaSpringBootTests {

    @Mock
    private ClienteRepository clienteRepository;

    @Mock
    private PizzaRepository pizzaRepository;

    @Mock
    private PedidoRepository pedidoRepository;

    @InjectMocks
    private ClienteService clienteService;

    @InjectMocks
    private PizzaService pizzaService;

    @InjectMocks
    private PedidoService pedidoService;

    @Test
    @DisplayName("UT01 - Servicio Cliente: Guardar y listar clientes correctamente")
    void testClienteServiceGuardarYListar() {
        Cliente cliente = new Cliente(1, "Carlos Mendoza", "3101234567", "Calle 12 # 34-56");
        when(clienteRepository.save(any(Cliente.class))).thenReturn(cliente);
        when(clienteRepository.findAll()).thenReturn(List.of(cliente));

        Cliente guardado = clienteService.guardar(cliente);
        assertNotNull(guardado);
        assertEquals("Carlos Mendoza", guardado.getNombre());

        List<Cliente> lista = clienteService.listarTodos();
        assertFalse(lista.isEmpty());
        assertEquals(1, lista.size());
    }

    @Test
    @DisplayName("UT02 - Servicio Pizza: Consulta por ID y filtros de catálogo")
    void testPizzaServiceConsultaYFiltros() {
        Pizza pizza = new Pizza(1, "Hawaiana", "Grande", new BigDecimal("38000.00"));
        when(pizzaRepository.findById(1)).thenReturn(Optional.of(pizza));
        when(pizzaRepository.findByTamano("Grande")).thenReturn(List.of(pizza));

        Optional<Pizza> encontrada = pizzaService.obtenerPorId(1);
        assertTrue(encontrada.isPresent());
        assertEquals("Hawaiana", encontrada.get().getNombre());

        List<Pizza> grandes = pizzaService.buscarPorTamano("Grande");
        assertEquals(1, grandes.size());
    }

    @Test
    @DisplayName("UT03 - Servicio Pedido: Cálculo atómico de subtotales y creación de comanda")
    void testPedidoServiceCalculoSubtotales() {
        Cliente cliente = new Cliente(1, "Ana Ramirez", "3209876543", "Carrera 45 # 12-89");
        Pizza pizza1 = new Pizza(1, "Pepperoni", "Mediana", new BigDecimal("25000.00"));
        Pizza pizza2 = new Pizza(2, "Cuatro Quesos", "Personal", new BigDecimal("15000.00"));

        when(clienteRepository.findById(1)).thenReturn(Optional.of(cliente));
        when(pizzaRepository.findById(1)).thenReturn(Optional.of(pizza1));
        when(pizzaRepository.findById(2)).thenReturn(Optional.of(pizza2));
        when(pedidoRepository.save(any(Pedido.class))).thenAnswer(invocation -> invocation.getArgument(0));

        PedidoRequestDTO request = new PedidoRequestDTO();
        request.setIdCliente(1);
        request.setEstado("En Preparación");
        request.setItems(List.of(
                new ItemPedidoDTO(1, 2), // 2 * 25,000 = 50,000
                new ItemPedidoDTO(2, 1)  // 1 * 15,000 = 15,000
        ));

        Pedido pedidoCreado = pedidoService.crearPedido(request);
        assertNotNull(pedidoCreado);
        assertEquals(new BigDecimal("65000.00"), pedidoCreado.getTotal());
        assertEquals(2, pedidoCreado.getDetalles().size());
        assertEquals("En Preparación", pedidoCreado.getEstado());
        verify(pedidoRepository).save(any(Pedido.class));
    }

    @Test
    @DisplayName("UT04 - Servicio Cliente: Eliminación y verificación de existencia")
    void testClienteServiceEliminar() {
        when(clienteRepository.existsById(5)).thenReturn(true);

        boolean eliminado = clienteService.eliminar(5);
        assertTrue(eliminado);
        verify(clienteRepository).deleteById(5);
    }
}
