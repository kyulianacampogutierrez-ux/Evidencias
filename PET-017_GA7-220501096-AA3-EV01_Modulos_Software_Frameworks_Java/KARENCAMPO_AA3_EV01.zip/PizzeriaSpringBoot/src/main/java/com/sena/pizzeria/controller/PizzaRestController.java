package com.sena.pizzeria.controller;

import com.sena.pizzeria.entity.Pizza;
import com.sena.pizzeria.service.PizzaService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.List;

/**
 * Controlador REST para el catálogo de pizzas y fijación de precios.
 * 
 * @author Karen Yuliana Campo
 * @version 1.0.0
 */
@RestController
@RequestMapping("/pizzas")
public class PizzaRestController {

    private final PizzaService pizzaService;

    public PizzaRestController(PizzaService pizzaService) {
        this.pizzaService = pizzaService;
    }

    @GetMapping
    public ResponseEntity<List<Pizza>> listarTodas() {
        return ResponseEntity.ok(pizzaService.listarTodas());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Pizza> obtenerPorId(@PathVariable Integer id) {
        return pizzaService.obtenerPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/tamano/{tamano}")
    public ResponseEntity<List<Pizza>> buscarPorTamano(@PathVariable String tamano) {
        return ResponseEntity.ok(pizzaService.buscarPorTamano(tamano));
    }

    @GetMapping("/precio-maximo")
    public ResponseEntity<List<Pizza>> buscarPorPrecioMaximo(@RequestParam BigDecimal precio) {
        return ResponseEntity.ok(pizzaService.buscarPorPrecioMaximo(precio));
    }

    @PostMapping
    public ResponseEntity<Pizza> crearPizza(@Valid @RequestBody Pizza pizza) {
        Pizza nueva = pizzaService.guardar(pizza);
        return ResponseEntity.status(HttpStatus.CREATED).body(nueva);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Pizza> actualizarPizza(@PathVariable Integer id, @Valid @RequestBody Pizza pizza) {
        return pizzaService.actualizar(id, pizza)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarPizza(@PathVariable Integer id) {
        if (pizzaService.eliminar(id)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
