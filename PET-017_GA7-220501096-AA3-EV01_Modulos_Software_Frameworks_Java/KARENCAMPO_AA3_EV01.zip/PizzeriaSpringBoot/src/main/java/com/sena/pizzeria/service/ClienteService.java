package com.sena.pizzeria.service;

import com.sena.pizzeria.entity.Cliente;
import com.sena.pizzeria.repository.ClienteRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Servicio de negocio para la gestión de clientes.
 * Aplica lógica de validación y control transaccional con Spring.
 * 
 * @author Karen Yuliana Campo
 * @version 1.0.0
 */
@Service
@Transactional(readOnly = true)
public class ClienteService {

    private final ClienteRepository clienteRepository;

    public ClienteService(ClienteRepository clienteRepository) {
        this.clienteRepository = clienteRepository;
    }

    public List<Cliente> listarTodos() {
        return clienteRepository.findAll();
    }

    public Optional<Cliente> obtenerPorId(Integer id) {
        return clienteRepository.findById(id);
    }

    public List<Cliente> buscarPorNombre(String nombre) {
        return clienteRepository.findByNombreContainingIgnoreCase(nombre);
    }

    @Transactional
    public Cliente guardar(Cliente cliente) {
        return clienteRepository.save(cliente);
    }

    @Transactional
    public Optional<Cliente> actualizar(Integer id, Cliente datos) {
        return clienteRepository.findById(id).map(clienteExistente -> {
            clienteExistente.setNombre(datos.getNombre());
            clienteExistente.setTelefono(datos.getTelefono());
            clienteExistente.setDireccion(datos.getDireccion());
            return clienteRepository.save(clienteExistente);
        });
    }

    @Transactional
    public boolean eliminar(Integer id) {
        if (clienteRepository.existsById(id)) {
            clienteRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
