package com.sena.pizzeria.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import java.util.List;

public class PedidoRequestDTO {

    @NotNull(message = "El idCliente es obligatorio")
    private Integer idCliente;

    private String estado = "En Preparación";

    @NotEmpty(message = "El pedido debe contener al menos un ítem")
    private List<ItemPedidoDTO> items;

    public PedidoRequestDTO() {
    }

    public PedidoRequestDTO(Integer idCliente, String estado, List<ItemPedidoDTO> items) {
        this.idCliente = idCliente;
        this.estado = estado;
        this.items = items;
    }

    public Integer getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(Integer idCliente) {
        this.idCliente = idCliente;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public List<ItemPedidoDTO> getItems() {
        return items;
    }

    public void setItems(List<ItemPedidoDTO> items) {
        this.items = items;
    }
}
