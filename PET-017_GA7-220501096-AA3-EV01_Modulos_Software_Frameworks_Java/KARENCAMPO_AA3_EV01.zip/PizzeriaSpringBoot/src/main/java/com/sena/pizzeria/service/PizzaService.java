package com.sena.pizzeria.service;

import com.sena.pizzeria.entity.Pizza;
import com.sena.pizzeria.repository.PizzaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

/**
 * Servicio de negocio para la administración del menú de pizzas.
 * 
 * @author Karen Yuliana Campo
 * @version 1.0.0
 */
@Service
@Transactional(readOnly = true)
public class PizzaService {

    private final PizzaRepository pizzaRepository;

    public PizzaService(PizzaRepository pizzaRepository) {
        this.pizzaRepository = pizzaRepository;
    }

    public List<Pizza> listarTodas() {
        return pizzaRepository.findAll();
    }

    public Optional<Pizza> obtenerPorId(Integer id) {
        return pizzaRepository.findById(id);
    }

    public List<Pizza> buscarPorTamano(String tamano) {
        return pizzaRepository.findByTamano(tamano);
    }

    public List<Pizza> buscarPorPrecioMaximo(BigDecimal precioMax) {
        return pizzaRepository.findByPrecioLessThanEqual(precioMax);
    }

    @Transactional
    public Pizza guardar(Pizza pizza) {
        return pizzaRepository.save(pizza);
    }

    @Transactional
    public Optional<Pizza> actualizar(Integer id, Pizza datos) {
        return pizzaRepository.findById(id).map(existente -> {
            existente.setNombre(datos.getNombre());
            existente.setTamano(datos.getTamano());
            existente.setPrecio(datos.getPrecio());
            return pizzaRepository.save(existente);
        });
    }

    @Transactional
    public boolean eliminar(Integer id) {
        if (pizzaRepository.existsById(id)) {
            pizzaRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
