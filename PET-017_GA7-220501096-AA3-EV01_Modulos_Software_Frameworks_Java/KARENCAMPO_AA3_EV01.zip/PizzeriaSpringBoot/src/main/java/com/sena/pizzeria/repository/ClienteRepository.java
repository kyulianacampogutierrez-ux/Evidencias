package com.sena.pizzeria.repository;

import com.sena.pizzeria.entity.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repositorio Spring Data JPA para la entidad Cliente.
 * Proporciona métodos CRUD estándar y consultas derivadas de métodos.
 * 
 * @author Karen Yuliana Campo
 * @version 1.0.0
 */
@Repository
public interface ClienteRepository extends JpaRepository<Cliente, Integer> {

    Optional<Cliente> findByTelefono(String telefono);

    List<Cliente> findByNombreContainingIgnoreCase(String nombre);
}
