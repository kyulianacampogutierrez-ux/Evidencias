package com.sena.pizzeria.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

/**
 * Entidad JPA que representa una especialidad de pizza en el menú.
 * Mapea la tabla relacional PIZZAS.
 * 
 * @author Karen Yuliana Campo
 * @version 1.0.0
 */
@Entity
@Table(name = "PIZZAS")
public class Pizza {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_pizza")
    private Integer idPizza;

    @NotBlank(message = "El nombre de la pizza no puede estar vacío")
    @Size(min = 3, max = 80, message = "El nombre debe tener entre 3 y 80 caracteres")
    @Column(name = "nombre", nullable = false, length = 80)
    private String nombre;

    @NotBlank(message = "El tamaño es obligatorio (Personal, Mediana, Grande, Familiar)")
    @Column(name = "tamano", nullable = false, length = 20)
    private String tamano;

    @NotNull(message = "El precio de la pizza es obligatorio")
    @DecimalMin(value = "5000.0", message = "El precio mínimo permitido es de $5.000 COP")
    @Column(name = "precio", nullable = false, precision = 10, scale = 2)
    private BigDecimal precio;

    public Pizza() {
    }

    public Pizza(Integer idPizza, String nombre, String tamano, BigDecimal precio) {
        this.idPizza = idPizza;
        this.nombre = nombre;
        this.tamano = tamano;
        this.precio = precio;
    }

    public Pizza(String nombre, String tamano, BigDecimal precio) {
        this.nombre = nombre;
        this.tamano = tamano;
        this.precio = precio;
    }

    public Integer getIdPizza() {
        return idPizza;
    }

    public void setIdPizza(Integer idPizza) {
        this.idPizza = idPizza;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTamano() {
        return tamano;
    }

    public void setTamano(String tamano) {
        this.tamano = tamano;
    }

    public BigDecimal getPrecio() {
        return precio;
    }

    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Pizza{" +
                "idPizza=" + idPizza +
                ", nombre='" + nombre + '\'' +
                ", tamano='" + tamano + '\'' +
                ", precio=" + precio +
                '}';
    }
}
