package com.sena.pizzeria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Clase principal de inicio para la aplicación Spring Boot de la Pizzería Bella Italia.
 * Desarrollado para la evidencia GA7-220501096-AA3-EV01 del programa ADSO.
 * 
 * @author Karen Yuliana Campo
 * @version 1.0.0
 */
@SpringBootApplication
public class PizzeriaApplication {

    public static void main(String[] args) {
        SpringApplication.run(PizzeriaApplication.class, args);
        System.out.println("==========================================================");
        System.out.println("🍕 API REST Spring Boot - Pizzería Bella Italia INICIADA");
        System.out.println("📍 Regional Cauca - Popayán | Ficha 228118 ADSO");
        System.out.println("🚀 Documentación y Endpoints listos en el contexto /api");
        System.out.println("==========================================================");
    }
}
