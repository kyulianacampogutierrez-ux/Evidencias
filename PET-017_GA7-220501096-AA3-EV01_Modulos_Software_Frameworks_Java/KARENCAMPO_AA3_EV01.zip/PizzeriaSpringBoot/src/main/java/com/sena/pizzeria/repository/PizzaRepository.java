package com.sena.pizzeria.repository;

import com.sena.pizzeria.entity.Pizza;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

/**
 * Repositorio Spring Data JPA para la entidad Pizza.
 * 
 * @author Karen Yuliana Campo
 * @version 1.0.0
 */
@Repository
public interface PizzaRepository extends JpaRepository<Pizza, Integer> {

    List<Pizza> findByTamano(String tamano);

    List<Pizza> findByPrecioLessThanEqual(BigDecimal precioMax);

    List<Pizza> findByNombreContainingIgnoreCase(String nombre);
}
