package com.sena.pizzeria.service;

import com.sena.pizzeria.dto.ItemPedidoDTO;
import com.sena.pizzeria.dto.PedidoRequestDTO;
import com.sena.pizzeria.entity.Cliente;
import com.sena.pizzeria.entity.DetallePedido;
import com.sena.pizzeria.entity.Pedido;
import com.sena.pizzeria.entity.Pizza;
import com.sena.pizzeria.repository.ClienteRepository;
import com.sena.pizzeria.repository.PedidoRepository;
import com.sena.pizzeria.repository.PizzaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Servicio de negocio transaccional para la gestión de órdenes de venta.
 * Realiza cálculos de subtotales, totales y verifica la existencia de clientes y pizzas.
 * 
 * @author Karen Yuliana Campo
 * @version 1.0.0
 */
@Service
@Transactional(readOnly = true)
public class PedidoService {

    private final PedidoRepository pedidoRepository;
    private final ClienteRepository clienteRepository;
    private final PizzaRepository pizzaRepository;

    public PedidoService(PedidoRepository pedidoRepository,
                         ClienteRepository clienteRepository,
                         PizzaRepository pizzaRepository) {
        this.pedidoRepository = pedidoRepository;
        this.clienteRepository = clienteRepository;
        this.pizzaRepository = pizzaRepository;
    }

    public List<Pedido> listarTodos() {
        return pedidoRepository.findAll();
    }

    public Optional<Pedido> obtenerPorId(Integer id) {
        return pedidoRepository.findById(id);
    }

    public List<Pedido> buscarPorCliente(Integer idCliente) {
        return pedidoRepository.findByClienteIdCliente(idCliente);
    }

    public List<Pedido> buscarPorEstado(String estado) {
        return pedidoRepository.findByEstado(estado);
    }

    @Transactional
    public Pedido crearPedido(PedidoRequestDTO request) {
        Cliente cliente = clienteRepository.findById(request.getIdCliente())
                .orElseThrow(() -> new IllegalArgumentException("Cliente no encontrado con ID: " + request.getIdCliente()));

        Pedido pedido = new Pedido();
        pedido.setCliente(cliente);
        pedido.setFechaPedido(LocalDateTime.now());
        pedido.setEstado(request.getEstado() != null ? request.getEstado() : "En Preparación");

        BigDecimal granTotal = BigDecimal.ZERO;

        for (ItemPedidoDTO item : request.getItems()) {
            Pizza pizza = pizzaRepository.findById(item.getIdPizza())
                    .orElseThrow(() -> new IllegalArgumentException("Pizza no encontrada con ID: " + item.getIdPizza()));

            BigDecimal precioUnitario = pizza.getPrecio();
            BigDecimal subtotal = precioUnitario.multiply(BigDecimal.valueOf(item.getCantidad()));
            granTotal = granTotal.add(subtotal);

            DetallePedido detalle = new DetallePedido();
            detalle.setPizza(pizza);
            detalle.setCantidad(item.getCantidad());
            detalle.setPrecioUnitario(precioUnitario);
            detalle.setSubtotal(subtotal);

            pedido.agregarDetalle(detalle);
        }

        pedido.setTotal(granTotal);
        return pedidoRepository.save(pedido);
    }

    @Transactional
    public Optional<Pedido> actualizarEstado(Integer id, String nuevoEstado) {
        return pedidoRepository.findById(id).map(pedido -> {
            pedido.setEstado(nuevoEstado);
            return pedidoRepository.save(pedido);
        });
    }

    @Transactional
    public boolean eliminar(Integer id) {
        if (pedidoRepository.existsById(id)) {
            pedidoRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
