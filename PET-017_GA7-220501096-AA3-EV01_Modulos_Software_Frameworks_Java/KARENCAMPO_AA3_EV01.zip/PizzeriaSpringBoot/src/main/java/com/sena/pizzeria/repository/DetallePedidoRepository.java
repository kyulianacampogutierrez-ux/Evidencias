package com.sena.pizzeria.repository;

import com.sena.pizzeria.entity.DetallePedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repositorio Spring Data JPA para la entidad DetallePedido.
 * 
 * @author Karen Yuliana Campo
 * @version 1.0.0
 */
@Repository
public interface DetallePedidoRepository extends JpaRepository<DetallePedido, Integer> {

    List<DetallePedido> findByPedidoIdPedido(Integer idPedido);
}
