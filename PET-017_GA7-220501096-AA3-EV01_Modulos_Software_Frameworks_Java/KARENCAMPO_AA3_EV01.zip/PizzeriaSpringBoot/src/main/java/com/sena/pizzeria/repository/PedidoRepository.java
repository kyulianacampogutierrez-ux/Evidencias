package com.sena.pizzeria.repository;

import com.sena.pizzeria.entity.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repositorio Spring Data JPA para la entidad Pedido.
 * 
 * @author Karen Yuliana Campo
 * @version 1.0.0
 */
@Repository
public interface PedidoRepository extends JpaRepository<Pedido, Integer> {

    List<Pedido> findByClienteIdCliente(Integer idCliente);

    List<Pedido> findByEstado(String estado);
}
