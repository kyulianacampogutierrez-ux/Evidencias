# Módulo de Backend con Framework Spring Boot y JPA - Pizzería Bella Italia
## Evidencia SENA: GA7-220501096-AA3-EV01

### 📌 Información Formativa
- **Aprendiz:** Karen Yuliana Campo
- **Ficha:** 228118
- **Programa:** Análisis y Desarrollo de Software (ADSO) - Modalidad Virtual
- **Centro:** Centro de Teleinformática y Producción Industrial (CTPI) - Regional Cauca
- **Actividad:** GA7-220501096-AA3: Codificar los módulos del software stand-alone, web y móvil.

---

### 🚀 Tecnologías Implementadas
- **Lenguaje:** Java 17 LTS (Eclipse Temurin)
- **Framework Principal:** Spring Boot 3.2.5
- **Persistencia:** Spring Data JPA + Hibernate ORM
- **Validaciones:** Jakarta Bean Validation (`@NotBlank`, `@Min`, `@Pattern`, `@Size`)
- **Base de Datos:** MariaDB 10.5 contenerizada en Docker
- **Pruebas Unitarias:** JUnit 5 + Mockito + Spring Boot Test
- **Arquitectura:** Capas desacopladas (Controller REST -> Service -> Repository -> Entity)

---

### 🌐 Endpoints de la API REST (`/api`)

#### 1. Módulo de Clientes (`/api/clientes`)
- `GET /api/clientes`: Listado general de clientes.
- `GET /api/clientes/{id}`: Consulta por clave primaria.
- `GET /api/clientes/buscar?nombre={nombre}`: Filtro por nombre parcial.
- `POST /api/clientes`: Registro de cliente (Body JSON con validaciones).
- `PUT /api/clientes/{id}`: Modificación de cliente.
- `DELETE /api/clientes/{id}`: Eliminación de cliente.

#### 2. Catálogo de Pizzas (`/api/pizzas`)
- `GET /api/pizzas`: Menú completo de pizzas.
- `GET /api/pizzas/{id}`: Búsqueda por ID.
- `GET /api/pizzas/tamano/{tamano}`: Filtro por tamaño.
- `GET /api/pizzas/precio-maximo?precio={precio}`: Filtro por rango de precio.
- `POST /api/pizzas`: Incorporación de nueva especialidad.
- `PUT /api/pizzas/{id}`: Actualización de precio o especialidad.
- `DELETE /api/pizzas/{id}`: Eliminación de especialidad.

#### 3. Gestión de Pedidos (`/api/pedidos`)
- `GET /api/pedidos`: Listado histórico de comandas de venta.
- `GET /api/pedidos/{id}`: Comanda por ID con detalle de ítems.
- `GET /api/pedidos/cliente/{idCliente}`: Pedidos de un cliente específico.
- `POST /api/pedidos`: Creación transaccional de comanda con cálculo de subtotales.
- `PATCH /api/pedidos/{id}/estado?nuevoEstado={estado}`: Cambio de estado de preparación.
- `DELETE /api/pedidos/{id}`: Cancelación de comanda.

---

### 🐳 Ejecución con Docker

```bash
# 1. Iniciar la base de datos MariaDB
docker-compose up -d db

# 2. Compilar y empaquetar
mvn clean package

# 3. Ejecutar el microservicio Spring Boot en contenedor
docker run --rm -p 8082:8082 --network sena_network \
  -e DB_HOST=db -e DB_PORT=3306 -e DB_NAME=pizzeria \
  -e DB_USER=karen -e DB_PASS=choco \
  -v $(pwd)/target:/app \
  eclipse-temurin:17-jre-alpine java -jar /app/pizzeria-spring-boot-1.0.0.jar
```
