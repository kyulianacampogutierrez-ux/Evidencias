#!/usr/bin/env python3
# ==============================================================================
# COMPILADOR DE INFORME TÉCNICO FORMAL PDF Y WORD (SENA ADSO GUÍA 8 - AA2-EV01)
# Evidencia: GA8-220601501-AA2-EV01 - Diagrama de Ishikawa sobre estrategias para
# la prevención y control de impactos ambientales, accidentes y enfermedades laborales (ATEL)
# Aprendiz: Karen Yuliana Campo | Ficha: 3186681 | CTPI Popayán - Regional Cauca
# ==============================================================================

import os
import subprocess
import shutil

BASE_DIR = '/home/danilo/Escritorio/Karen/SENA/CDE/Evidencias/PET-032_GA8-220601501-AA2-EV01_Diagrama_Ishikawa_ATEL'
DOCS_DIR = os.path.join(BASE_DIR, 'docs')
DIAG_DIR = os.path.join(BASE_DIR, 'diagramas')
ENTREGA_DIR = '/home/danilo/Escritorio/Karen/SENA/ENTREGA_ZAJUNA_GA8-220601501-AA2-EV01'

os.makedirs(DOCS_DIR, exist_ok=True)
os.makedirs(ENTREGA_DIR, exist_ok=True)

p1_path = os.path.join(DIAG_DIR, 'diagrama_ishikawa_atel_vestidos_costuras.png')
p2_path = os.path.join(DIAG_DIR, 'diagrama_ishikawa_ambiental_textil.png')
p3_path = os.path.join(DIAG_DIR, 'plan_estrategico_atel_ambiental.png')

html_content = f"""<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Diagrama de Ishikawa ATEL y Ambiental - GA8-AA2-EV01 | Karen Campo</title>
  <style>
    @page {{
      size: letter;
      margin: 1.8cm 1.6cm 1.8cm 1.6cm;
      @bottom-right {{
        content: counter(page);
      }}
    }}
    * {{
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }}
    body {{
      font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
      color: #1e293b;
      line-height: 1.5;
      font-size: 9.5pt;
      background: #ffffff;
    }}
    .page-break {{
      page-break-before: always;
    }}
    
    /* PORTADA OFICIAL SENA */
    .cover {{
      height: 94vh;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      border: 3px solid #059669;
      padding: 35px 30px;
      background: linear-gradient(180deg, #f0fdf4 0%, #ffffff 100%);
      border-radius: 8px;
    }}
    .cover-header {{
      text-align: center;
      border-bottom: 2px solid #059669;
      padding-bottom: 18px;
    }}
    .cover-header h1 {{
      font-size: 19pt;
      color: #065f46;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-bottom: 6px;
    }}
    .cover-header h2 {{
      font-size: 13pt;
      color: #0f172a;
      font-weight: 600;
    }}
    .cover-header h3 {{
      font-size: 10pt;
      color: #64748b;
      margin-top: 4px;
    }}
    .cover-badge {{
      display: inline-block;
      background: #059669;
      color: white;
      padding: 4px 14px;
      border-radius: 20px;
      font-size: 9pt;
      font-weight: bold;
      margin-top: 10px;
    }}
    .cover-body {{
      text-align: center;
      margin: 20px 0;
    }}
    .cover-title {{
      font-size: 18pt;
      color: #0f172a;
      font-weight: 800;
      line-height: 1.3;
      margin-bottom: 15px;
    }}
    .cover-subtitle {{
      font-size: 11pt;
      color: #334155;
      max-width: 650px;
      margin: 0 auto 20px auto;
      line-height: 1.4;
    }}
    .cover-info-card {{
      background: #ffffff;
      border: 1px solid #cbd5e1;
      border-left: 5px solid #059669;
      border-radius: 6px;
      padding: 15px;
      display: inline-block;
      text-align: left;
      margin: 0 auto;
      min-width: 450px;
    }}
    .cover-info-row {{
      font-size: 9.5pt;
      margin-bottom: 6px;
    }}
    .cover-info-row:last-child {{
      margin-bottom: 0;
    }}
    .cover-info-label {{
      font-weight: bold;
      color: #065f46;
      display: inline-block;
      width: 150px;
    }}
    .cover-footer {{
      text-align: center;
      border-top: 1px solid #cbd5e1;
      padding-top: 15px;
      font-size: 9pt;
      color: #64748b;
    }}

    /* ENCABEZADOS Y TEXTO */
    .header-running {{
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #cbd5e1;
      padding-bottom: 4px;
      margin-bottom: 15px;
      font-size: 8pt;
      color: #64748b;
      text-transform: uppercase;
    }}
    h1.sec-title {{
      font-size: 13pt;
      color: #065f46;
      border-bottom: 2px solid #059669;
      padding-bottom: 4px;
      margin-top: 18px;
      margin-bottom: 10px;
      text-transform: uppercase;
      page-break-after: avoid;
    }}
    h2.subsec-title {{
      font-size: 11pt;
      color: #0f172a;
      margin-top: 12px;
      margin-bottom: 6px;
      border-left: 3px solid #059669;
      padding-left: 8px;
      page-break-after: avoid;
    }}
    p {{
      margin-bottom: 8px;
      text-align: justify;
    }}
    ul, ol {{
      margin-left: 20px;
      margin-bottom: 10px;
    }}
    li {{
      margin-bottom: 4px;
    }}

    /* TABLAS ESTILIZADAS */
    table {{
      width: 100%;
      border-collapse: collapse;
      margin: 12px 0;
      font-size: 8.5pt;
      page-break-inside: avoid;
    }}
    th {{
      background-color: #065f46;
      color: #ffffff;
      padding: 7px 8px;
      text-align: left;
      font-weight: 600;
      border: 1px solid #047857;
    }}
    td {{
      padding: 6px 8px;
      border: 1px solid #cbd5e1;
      vertical-align: top;
    }}
    tr:nth-child(even) {{
      background-color: #f8fafc;
    }}
    .badge {{
      display: inline-block;
      padding: 2px 7px;
      border-radius: 4px;
      font-size: 7.5pt;
      font-weight: bold;
    }}
    .badge-urgent {{
      background: #fef2f2;
      color: #991b1b;
      border: 1px solid #f87171;
    }}
    .badge-warn {{
      background: #fffbeb;
      color: #92400e;
      border: 1px solid #fcd34d;
    }}
    .badge-success {{
      background: #ecfdf5;
      color: #065f46;
      border: 1px solid #6ee7b7;
    }}

    /* CAJAS DE INFORMACIÓN */
    .callout {{
      background-color: #f0fdf4;
      border: 1px solid #bbf7d0;
      border-left: 4px solid #059669;
      padding: 10px 14px;
      border-radius: 4px;
      margin: 10px 0;
      font-size: 9pt;
    }}
    .callout-title {{
      font-weight: bold;
      color: #065f46;
      margin-bottom: 4px;
    }}
    .quote-box {{
      background: #f8fafc;
      border-left: 4px solid #64748b;
      padding: 10px 14px;
      margin: 10px 0;
      font-style: italic;
      color: #334155;
    }}

    /* DIAGRAMAS */
    .diagram-container {{
      text-align: center;
      margin: 15px 0;
      page-break-inside: avoid;
    }}
    .diagram-img {{
      max-width: 98%;
      height: auto;
      border: 1px solid #cbd5e1;
      border-radius: 6px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.06);
    }}
    .diagram-caption {{
      font-size: 8pt;
      color: #64748b;
      margin-top: 5px;
      font-style: italic;
    }}
  </style>
</head>
<body>

  <!-- ==================== PORTADA ==================== -->
  <div class="cover">
    <div class="cover-header">
      <h1>Servicio Nacional de Aprendizaje - SENA</h1>
      <h2>Centro de Teleinformática y Producción Industrial (CTPI)</h2>
      <h3>Regional Cauca • Popayán</h3>
      <div class="cover-badge">PROGRAMA ADSO • FICHA 3186681</div>
    </div>

    <div class="cover-body">
      <div class="cover-title">
        DIAGRAMA DE ISHIKAWA (ESPINA DE PESCADO):<br>
        ESTRATEGIAS PARA LA PREVENCIÓN Y CONTROL DE IMPACTOS AMBIENTALES, ACCIDENTES Y ENFERMEDADES LABORALES (ATEL)
      </div>
      <div class="cover-subtitle">
        Investigación de causa raíz mediante metodología 6M para la empresa "Vestidos y Costuras S.A.S.", matriz de estrategias jerarquizadas bajo Decreto 1072/2015, Resolución 0312/2019, ISO 14001 y transferencia técnica al proyecto formativo Pizzería Gourmet Bella Italia Popayán.
      </div>

      <div class="cover-info-card">
        <div class="cover-info-row">
          <span class="cover-info-label">Evidencia:</span>
          <strong>GA8-220601501-AA2-EV01</strong>
        </div>
        <div class="cover-info-row">
          <span class="cover-info-label">Competencia:</span>
          <span>220601501 - Protección ambiental y SST</span>
        </div>
        <div class="cover-info-row">
          <span class="cover-info-label">Aprendiz:</span>
          <strong>Karen Yuliana Campo</strong>
        </div>
        <div class="cover-info-row">
          <span class="cover-info-label">Ficha Formativa:</span>
          <strong>3186681</strong>
        </div>
        <div class="cover-info-row">
          <span class="cover-info-label">Proyecto Formativo:</span>
          <span>Pizzería Gourmet Bella Italia Popayán</span>
        </div>
        <div class="cover-info-row">
          <span class="cover-info-label">Lugar y Fecha:</span>
          <span>Popayán, Cauca — Noviembre 2026</span>
        </div>
      </div>
    </div>

    <div class="cover-footer">
      Tecnología en Análisis y Desarrollo de Software • Modalidad Virtual<br>
      Sistema Integrado de Gestión y Autocontrol (SIGA-SENA)
    </div>
  </div>

  <div class="page-break"></div>

  <!-- ==================== SECCIÓN 1: INTRODUCCIÓN ==================== -->
  <div class="header-running">
    <span>SENA CTPI Popayán • ADSO Ficha 3186681</span>
    <span>GA8-220601501-AA2-EV01: Diagrama de Ishikawa ATEL y Ambiental</span>
  </div>

  <h1 class="sec-title">1. INTRODUCCIÓN Y FUNDAMENTO METODOLÓGICO</h1>
  <p>
    En el marco del Sistema de Gestión de la Seguridad y Salud en el Trabajo (<strong>SG-SST</strong>) y los Planes Institucionales de Gestión Ambiental (<strong>PIGA</strong>), la prevención de accidentes y mitigación de impactos no puede fundamentarse en apreciaciones empíricas o en la asignación apresurada de culpas individuales. Toda manifestación de peligro o daño deriva de una interacción multicausal de variables operativas, técnicas, locativas y directivas.
  </p>
  <p>
    El <strong>Diagrama de Ishikawa</strong> (o *Espina de Pescado* / Diagrama Causa-Efecto), formulado en 1943 por el químico japonés Kaoru Ishikawa, es la metodología analítica estándar para desentrañar la causa raíz de un problema focal a través del modelo de las <strong>6M</strong>:
  </p>

  <div class="callout">
    <div class="callout-title">Los 6 Pilares Sistémicos del Diagrama de Ishikawa (Modelo 6M)</div>
    <ul style="margin-bottom: 0;">
      <li><strong>1. Método:</strong> Procedimientos estandarizados, protocolos de movilización de cargas y prácticas de autocuidado.</li>
      <li><strong>2. Mano de Obra:</strong> Competencias técnicas, estado psicofisiológico de operarios, fatiga visual y adaptación lumínica.</li>
      <li><strong>3. Máquinas / Equipos:</strong> Maquinaria industrial bordadora, equipos de transporte vertical y luminarias de respaldo.</li>
      <li><strong>4. Materiales / EPP:</strong> Materias primas textiles, calzado de trabajo ergonómico con suela antideslizante certificada.</li>
      <li><strong>5. Entorno Locativo (Medio Ambiente de Trabajo):</strong> Condiciones arquitectónicas, niveles de iluminancia (lux), fricción de escaleras.</li>
      <li><strong>6. Medición / Gestión Administrativa:</strong> Auditoría del SG-SST, efectividad del COPASST y atención legal a reportes de peligro (Dec. 1072/2015).</li>
    </ul>
  </div>

  <h1 class="sec-title">2. CONTEXTUALIZACIÓN DEL CASO "VESTIDOS Y COSTURAS S.A.S."</h1>
  <div class="quote-box">
    "En la empresa 'Vestidos y costuras S.A.S.', los operarios que trabajan en las máquinas bordadoras, deben descender al sótano, donde se encuentran las máquinas que les permiten realizar su labor. Algunos de ellos han tenido caídas y tropiezos en las escaleras que los conducen hacia el sótano, debido a que, en este lugar, se cuenta con poca luz, lo que dificulta caminar de manera segura por las escaleras; esta situación fue expuesta al encargado del Sistema de Gestión de Seguridad y Salud en el Trabajo de la empresa, hace días atrás, aunque hasta la fecha, no se ha atendido la situación."
  </div>

  <table style="margin-top: 10px;">
    <thead>
      <tr>
        <th style="width: 25%;">Dimensión</th>
        <th style="width: 45%;">Diagnóstico Técnico en Caso</th>
        <th style="width: 30%;">Incumplimiento Normativo</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><strong>Síntoma Visible</strong></td>
        <td>Tropiezos, resbalones y caídas a distinto nivel en tramo de escaleras hacia sótano de bordado.</td>
        <td>Peligro locativo catalogado como Nivel de Riesgo I Crítico según Guía Técnica Colombiana GTC 45.</td>
      </tr>
      <tr>
        <td><strong>Condición Insegura</strong></td>
        <td>Déficit lumínico severo (&lt;50 Luxes medidos vs estándar de 200 Lux), peldaños lisos y ausencia de pasamanos continuo.</td>
        <td>Resolución 2400 de 1979 (Arts. 79, 80, 158 y 160) y RETILAP (Reglamento de Iluminación).</td>
      </tr>
      <tr>
        <td><strong>Falla Directiva Crítica</strong></td>
        <td>Inacción del responsable de SG-SST ante reporte formal de peligro radicado días atrás por los trabajadores.</td>
        <td>Vulneración flagrante del Art. 2.2.4.6.26 del Decreto 1072 de 2015 y Resolución 0312 de 2019.</td>
      </tr>
    </tbody>
  </table>

  <div class="page-break"></div>

  <!-- ==================== SECCIÓN 3: DIAGRAMA DE ISHIKAWA ATEL ==================== -->
  <div class="header-running">
    <span>SENA CTPI Popayán • ADSO Ficha 3186681</span>
    <span>GA8-220601501-AA2-EV01: Diagrama de Ishikawa ATEL y Ambiental</span>
  </div>

  <h1 class="sec-title">3. DIAGRAMA DE ISHIKAWA 6M: PREVENCIÓN DE ACCIDENTES Y ENFERMEDADES LABORALES (ATEL)</h1>
  <p>
    El siguiente diagrama ilustra la espina de pescado construida para desglosar la totalidad de causas directas y raíces que desencadenan las caídas y patologías osteomusculares y visuales en los operarios de máquinas bordadoras:
  </p>

  <!-- DIAGRAMA 1: ISHIKAWA ATEL -->
  <div class="diagram-container">
    <img src="file://{p1_path}" alt="Diagrama de Ishikawa 6M ATEL - Vestidos y Costuras S.A.S." class="diagram-img">
    <div class="diagram-caption">Figura 1: Diagrama de Causa-Efecto (6M) para prevención de accidentes y enfermedades laborales en escaleras y sótano.</div>
  </div>

  <h2 class="subsec-title">Desglose Analítico por Rama de las 6M (ATEL)</h2>
  <table>
    <thead>
      <tr>
        <th style="width: 18%;">Categoría (6M)</th>
        <th style="width: 42%;">Causa Primaria Identificada</th>
        <th style="width: 40%;">Causa Raíz Sistémica</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><strong>Método</strong></td>
        <td>Carencia de protocolo seguro de descenso y traslado manual de paquetes textiles que obstaculizan la visión.</td>
        <td>Ausencia de procedimientos normalizados de trabajo seguro (PTS) y descontrol en la estandarización operativa.</td>
      </tr>
      <tr>
        <td><strong>Mano de Obra</strong></td>
        <td>Prisas operativas por cuotas de confección; falta de adaptación pupilar brusca (de luz día a oscuridad del sótano).</td>
        <td>Presión de producción sobre seguridad laboral; déficit de capacitación en autocuidado y fatiga visual no diagnosticada.</td>
      </tr>
      <tr>
        <td><strong>Máquinas / Equipos</strong></td>
        <td>Taller de bordado relegado al sótano sin montacargas ni malacate para rollos textiles; sin balizas ni lámparas de emergencia.</td>
        <td>Decisión arquitectónica fabril sin criterio ergonómico; falta de inversión en automatización de transporte de insumos.</td>
      </tr>
      <tr>
        <td><strong>Materiales / EPP</strong></td>
        <td>Uso de calzado ordinario de calle (suelas sintéticas lisas); acumulación de pelusa y hebras textiles resbalosas en peldaños.</td>
        <td>No dotación de calzado de seguridad con suela antideslizante SRC según EN ISO 20345; deficiencia en programa de orden y aseo.</td>
      </tr>
      <tr>
        <td><strong>Entorno Locativo</strong></td>
        <td>Déficit lumínico crítico (&lt;50 Luxes); huellas de escalones desgastadas sin cinta de abrasión; pasamanos interrumpido.</td>
        <td>Falta de mantenimiento locativo correctivo y preventivo; desatención a normas técnicas colombianas de infraestructura segura.</td>
      </tr>
      <tr>
        <td><strong>Gestión SG-SST</strong></td>
        <td>Omisión negligente ante reporte previo de peligro efectuado por operarios; inoperancia del Comité Paritario (COPASST).</td>
        <td>Incumplimiento del Decreto 1072/2015 Art. 2.2.4.6.26; carencia de asignación presupuestal para contingencias y desinterés directivo.</td>
      </tr>
    </tbody>
  </table>

  <div class="page-break"></div>

  <!-- ==================== SECCIÓN 4: DIAGRAMA DE ISHIKAWA AMBIENTAL ==================== -->
  <div class="header-running">
    <span>SENA CTPI Popayán • ADSO Ficha 3186681</span>
    <span>GA8-220601501-AA2-EV01: Diagrama de Ishikawa ATEL y Ambiental</span>
  </div>

  <h1 class="sec-title">4. DIAGRAMA DE ISHIKAWA: PREVENCIÓN Y CONTROL DE IMPACTOS AMBIENTALES</h1>
  <p>
    En congruencia con la competencia <strong>220601501</strong>, la protección ambiental es inseparable de la seguridad ocupacional. El análisis de las actividades en el sótano y taller textil evidencia múltiples aspectos ambientales significativos que deben gestionarse bajo la norma <strong>ISO 14001:2015</strong> y la legislación colombiana (Decreto 1076 de 2015):
  </p>

  <!-- DIAGRAMA 2: ISHIKAWA AMBIENTAL -->
  <div class="diagram-container">
    <img src="file://{p2_path}" alt="Diagrama de Ishikawa Ambiental - Taller Textil Vestidos y Costuras S.A.S." class="diagram-img">
    <div class="diagram-caption">Figura 2: Diagrama de Ishikawa para la gestión y mitigación de aspectos e impactos ambientales en la industria textil.</div>
  </div>

  <h2 class="subsec-title">Matriz de Causas Raíz Ambientales en el Caso Textil</h2>
  <table>
    <thead>
      <tr>
        <th style="width: 22%;">Aspecto Ambiental</th>
        <th style="width: 38%;">Causa Raíz Identificada</th>
        <th style="width: 40%;">Impacto y Consecuencia Ambiental</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><strong>Consumo Energético</strong></td>
        <td>Uso de tubos fluorescentes obsoletos T12 y luminarias incandescentes que operan 24 horas continuas sin sensores de paso.</td>
        <td>Agotamiento de recursos naturales no renovables y alta huella de carbono asociada al consumo eléctrico ineficiente.</td>
      </tr>
      <tr>
        <td><strong>Residuos Peligrosos (RESPEL)</strong></td>
        <td>Lámparas de mercurio fundidas desechadas en la basura común; trapos impregnados de aceite mineral de bordadoras.</td>
        <td>Contaminación por metales pesados (vapor de mercurio e hidrocarburos) en el suelo y lixiviados de rellenos sanitarios.</td>
      </tr>
      <tr>
        <td><strong>Residuos Sólidos Ordinarios</strong></td>
        <td>Retazos de tela sintética (poliéster/nylon) mezclados en un solo contenedor sin separación en la fuente (Res. 2184/2019).</td>
        <td>Aceleración del colapso del relleno sanitario municipal con materiales que tardan más de 200 años en degradarse.</td>
      </tr>
      <tr>
        <td><strong>Emisiones de Ruido</strong></td>
        <td>Bordadoras multicabezal de alto tonelaje funcionando en espacio subterráneo cerrado con efecto de reverberación acústica (78 dB).</td>
        <td>Contaminación auditiva en el entorno laboral y fatiga neuroacústica en las operarias.</td>
      </tr>
      <tr>
        <td><strong>Manejo de Lubricantes</strong></td>
        <td>Lubricación manual excesiva de agujas y rodamientos sin bandejas de contención antiderrame.</td>
        <td>Riesgo de vertimiento accidental a la red de alcantarillado público y generación de pisos resbaladizos.</td>
      </tr>
    </tbody>
  </table>

  <div class="page-break"></div>

  <!-- ==================== SECCIÓN 5: PLAN ESTRATÉGICO ATEL Y AMBIENTAL ==================== -->
  <div class="header-running">
    <span>SENA CTPI Popayán • ADSO Ficha 3186681</span>
    <span>GA8-220601501-AA2-EV01: Diagrama de Ishikawa ATEL y Ambiental</span>
  </div>

  <h1 class="sec-title">5. PLAN INTEGRAL DE ESTRATEGIAS DE PREVENCIÓN Y CONTROL (ATEL Y AMBIENTAL)</h1>
  <p>
    Para erradicar de forma definitiva las causas raíz identificadas, se estructura un plan de acción sustentado en la <strong>Jerarquía de Controles</strong> (GTC 45 / Dec. 1072/2015) y en los programas del <strong>PIGA</strong>:
  </p>

  <!-- DIAGRAMA 3: PLAN ESTRATÉGICO -->
  <div class="diagram-container">
    <img src="file://{p3_path}" alt="Plan Estratégico Integral ATEL y Ambiental" class="diagram-img">
    <div class="diagram-caption">Figura 3: Pilares de intervención estratégica integral para la prevención de AT, EL y protección ambiental.</div>
  </div>

  <h2 class="subsec-title">5.1. Estrategias de Prevención de Accidentes de Trabajo (AT)</h2>
  <table>
    <thead>
      <tr>
        <th style="width: 20%;">Jerarquía de Control</th>
        <th style="width: 45%;">Medida Específica de Intervención</th>
        <th style="width: 17%;">Responsable</th>
        <th style="width: 18%;">Meta / Indicador</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><strong>1. Control de Ingeniería</strong> (Prioridad 1)</td>
        <td>Instalación de 4 paneles LED industriales herméticos IP65 de 40W (300 Lux en toda la escalera), sensor de movimiento infrarrojo y baliza de emergencia autónoma (90 min).</td>
        <td>Mantenimiento / Gerencia</td>
        <td><span class="badge badge-success">Luxometría &ge; 250 Lux</span> (100% tramos cubiertos)</td>
      </tr>
      <tr>
        <td><strong>2. Control de Ingeniería</strong> (Prioridad 2)</td>
        <td>Instalación de bandas fotoluminiscentes antideslizantes de alta abrasión en bordes de huella y colocación de pasamanos tubular doble a 90 cm y 60 cm anclado a muro.</td>
        <td>Infraestructura</td>
        <td><span class="badge badge-success">100% peldaños seguros</span> y pasamanos continuo</td>
      </tr>
      <tr>
        <td><strong>3. Control Administrativo</strong> (Gobernanza)</td>
        <td>Apertura de Acción Correctiva formal por omisión de reporte; implementación de plataforma digital de reporte de incidentes con alerta SMS a gerencia si excede 24 horas sin respuesta.</td>
        <td>Responsable SG-SST / COPASST</td>
        <td><span class="badge badge-success">Tiempo &lt; 24h</span> (0 no conformidades)</td>
      </tr>
      <tr>
        <td><strong>4. Control Administrativo</strong> (Procedimiento)</td>
        <td>Elaboración y socialización del PTS-04: Tránsito seguro en escaleras (regla de los 3 puntos de apoyo, prohibición de cargas al hombro y de uso de celular al descender).</td>
        <td>Talento Humano / Supervisión</td>
        <td><span class="badge badge-success">100% operarios evaluados</span> (&ge; 90 puntos)</td>
      </tr>
      <tr>
        <td><strong>5. Dotación de EPP</strong></td>
        <td>Entrega obligatoria y reposición semestral de calzado de seguridad ergonómico con suela de poliuretano antideslizante con coeficiente de fricción SRC (EN ISO 20345).</td>
        <td>Almacén / SG-SST</td>
        <td><span class="badge badge-success">100% dotación entregada</span> con firma de acta</td>
      </tr>
    </tbody>
  </table>

  <div class="page-break"></div>

  <!-- ==================== SECCIÓN 5.2 Y 5.3: ENFERMEDADES Y AMBIENTAL ==================== -->
  <div class="header-running">
    <span>SENA CTPI Popayán • ADSO Ficha 3186681</span>
    <span>GA8-220601501-AA2-EV01: Diagrama de Ishikawa ATEL y Ambiental</span>
  </div>

  <h2 class="subsec-title">5.2. Estrategias de Prevención de Enfermedades Laborales (EL)</h2>
  <table>
    <thead>
      <tr>
        <th style="width: 25%;">Patología Prevenida</th>
        <th style="width: 45%;">Acción Técnica de Prevención</th>
        <th style="width: 30%;">Impacto en Salud Laboral</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><strong>Trastornos Musculoesqueléticos (TME) y Cervicodorsalgias</strong></td>
        <td>Reemplazo de bancos fijos por sillas ergonómicas giratorias neumáticas con soporte lumbar ajustable y apoyabrazos; programa de pausas activas osteomusculares de 8 min cada 2 horas.</td>
        <td>Disminución del 80% en quejas por dolor lumbar crónico y prevención de hernias discales.</td>
      </tr>
      <tr>
        <td><strong>Fatiga Ocular, Astenopia y Cefaleas</strong></td>
        <td>Lámparas LED direccionales de luz blanca neutra (4000K) en cada cabezal de bordado; chequeos optométricos ocupacionales anuales con prescripción de filtros antirreflejo.</td>
        <td>Erradicación del esfuerzo acomodativo y disminución del ausentismo laboral por migrañas.</td>
      </tr>
      <tr>
        <td><strong>Hipoacusia Neurosensorial Inducida por Ruido (HNIR)</strong></td>
        <td>Instalación de paneles absorbentes acústicos en paredes del sótano y dotación de protectores auditivos de inserción tipo copa (atenuación NRR 24 dB).</td>
        <td>Control de dosis sonora por debajo de 80 dB(A) según Resolución 2400 de 1979.</td>
      </tr>
    </tbody>
  </table>

  <h2 class="subsec-title">5.3. Estrategias de Prevención y Mitigación de Impactos Ambientales</h2>
  <table>
    <thead>
      <tr>
        <th style="width: 25%;">Eje Ambiental</th>
        <th style="width: 45%;">Medida Específica de Control (PIGA)</th>
        <th style="width: 30%;">Beneficio Ecológico</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><strong>Eficiencia Energética</strong></td>
        <td>Sustitución del 100% del parque de iluminación fluorescente por tecnología LED de alta eficiencia con sensores infrarrojos pasivos (PIR) de apagado automático.</td>
        <td>Reducción del 65% en consumo de kWh mes y disminución directa de la huella de CO2 equivalente.</td>
      </tr>
      <tr>
        <td><strong>Gestión RESPEL (Mercurio)</strong></td>
        <td>Disposición segura de luminarias mercuriales agotadas mediante embalaje certificado y entrega a gestor posconsumo autorizado (Decreto 1076 de 2015).</td>
        <td>Cero mercurio en vertederos comunes; preservación de fuentes de agua freáticas.</td>
      </tr>
      <tr>
        <td><strong>Economía Circular Textil</strong></td>
        <td>Implementación de código de colores (Res. 2184/2019): caneca blanca para retazos limpios y alianza con microempresas de Popayán para fabricación de aislantes térmicos o estopa.</td>
        <td>Desvío del 90% de residuos textiles que anteriormente colapsaban los rellenos sanitarios.</td>
      </tr>
      <tr>
        <td><strong>Control de Hidrocarburos</strong></td>
        <td>Instalación de charolas antigoteo bajo las bordadoras y almacenamiento de lubricantes sobre tarimas de retención antiderrame.</td>
        <td>Protección absoluta de alcantarillados pluviales y sanitarios contra aceites pesados.</td>
      </tr>
    </tbody>
  </table>

  <div class="page-break"></div>

  <!-- ==================== SECCIÓN 6 Y 7: PROYECTO FORMATIVO Y CONCLUSIONES ==================== -->
  <div class="header-running">
    <span>SENA CTPI Popayán • ADSO Ficha 3186681</span>
    <span>GA8-220601501-AA2-EV01: Diagrama de Ishikawa ATEL y Ambiental</span>
  </div>

  <h1 class="sec-title">6. ARTICULACIÓN CON EL PROYECTO FORMATIVO: PIZZERÍA GOURMET BELLA ITALIA POPAYÁN</h1>
  <p>
    El ejercicio analítico desarrollado en el taller de confección se transfiere de manera directa al modelo operativo y técnico del proyecto formativo <strong>Pizzería Gourmet Bella Italia Popayán</strong>:
  </p>

  <div class="callout">
    <div class="callout-title">Transferencia de Ishikawa a los Entornos del Restaurante y el Software</div>
    <ul style="margin-bottom: 0;">
      <li>
        <strong>1. Bodega Subterránea de Insumos Pesados (Harina y Leña):</strong>
        La pizzería artesanal almacena sacos de harina de trigo de 50 kg y leña de roble en su bodega. Al igual que en "Vestidos y Costuras S.A.S.", se diseñan escaleras con pasamanos de acero inoxidable, bandas fotoluminiscentes y sensores de 300 luxes, prohibiendo estrictamente el descenso manual al hombro superior a 25 kg según la Resolución 2400/1979.
      </li>
      <li>
        <strong>2. Estación Ergonómica de Desarrollo de Software (ADSO):</strong>
        Para la jornada de programación de la aprendiz Karen Campo (módulos React Native, APIs Go y contratos inteligentes), se cuenta con puesto ergonómico con silla soporte lumbar regulable, base para monitor a nivel visual, teclado desacoplado y rutina programada de pausas activas laborales cada 2 horas para erradicar el síndrome del túnel carpiano.
      </li>
      <li>
        <strong>3. Economía Circular y Manejo de Aceites Usados (ACU):</strong>
        Clasificación de residuos orgánicos en caneca verde (restos de masa napolitana y cáscaras vegetales del mercado de Popayán) para compostaje rural en Timbío, y almacenamiento hermético de aceites de cocina usados (ACU) para su entrega a gestores certificados de biodiésel.
      </li>
    </ul>
  </div>

  <h1 class="sec-title">7. CONCLUSIONES</h1>
  <ol>
    <li>
      <strong>Efectividad del Diagrama de Ishikawa:</strong> Permitió superar el sesgo común de culpar a la "imprudencia" del trabajador, demostrando que los accidentes son producto de fallas encadenadas en el entorno locativo (oscuridad) y de la omisión negligente de la administración del SG-SST frente a reportes formales previos.
    </li>
    <li>
      <strong>Sinergia entre SST y Medio Ambiente:</strong> Las medidas de control de ingeniería generan una ganancia dual: la modernización lumínica a tecnología LED erradica el peligro de caídas mortales y al mismo tiempo disminuye en un 65% el consumo de kilovatios-hora, eliminando la generación de residuos tóxicos de vapor de mercurio.
    </li>
    <li>
      <strong>Responsabilidad Legal y Ética:</strong> La omisión ante reportes de peligro infringe el Artículo 2.2.4.6.26 del Decreto 1072 de 2015 y la Resolución 0312 de 2019, exponiendo a la empresa a sanciones de hasta 500 SMMLV y responsabilidad civil culposa ante siniestros con incapacidad permanente.
    </li>
    <li>
      <strong>Visión Integral del Tecnólogo ADSO:</strong> Para la aprendiz del SENA, este análisis confirma que el diseño de software y la optimización de procesos nunca deben abstraerse de la realidad material de las personas ni del cuidado irrestricto del ecosistema natural.
    </li>
  </ol>

  <h1 class="sec-title">8. REFERENCIAS BIBLIOGRÁFICAS (NORMAS APA 7MA EDICIÓN)</h1>
  <ul style="list-style-type: none; margin-left: 0;">
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Congreso de la República de Colombia. (2012). <em>Ley 1562 de 2012: Por la cual se modifica el Sistema de Riesgos Laborales y se dictan otras disposiciones en materia de Salud Ocupacional</em>. Diario Oficial No. 48.488.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Congreso de la República de Colombia. (2014). <em>Ley 1715 de 2014: Por medio de la cual se regula la integración de las energías renovables no convencionales al Sistema Energético Nacional</em>.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      ICONTEC. (2012). <em>Guía Técnica Colombiana GTC 45: Guía para la identificación de los peligros y la valoración de los riesgos en seguridad y salud en el trabajo</em> (2da ed.). Instituto Colombiano de Normas Técnicas y Certificación.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      ICONTEC. (1987). <em>Norma Técnica Colombiana NTC 1461: Higiene y seguridad. Colores y señales de seguridad</em>.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Ishikawa, K. (1986). <em>Guide to Quality Control</em> (2nd ed.). Asian Productivity Organization / Quality Resources.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Ministerio de Ambiente y Desarrollo Sostenible. (2015). <em>Decreto 1076 de 2015: Decreto Único Reglamentario del Sector Ambiente y Desarrollo Sostenible</em>.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Ministerio de Ambiente y Desarrollo Sostenible. (2019). <em>Resolución 2184 de 2019: Adopción del código de colores para la separación de residuos sólidos en la fuente</em>.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Ministerio de Trabajo y Seguridad Social. (1979). <em>Resolución 2400 de 1979: Estatuto de Seguridad Industrial</em>.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Ministerio del Trabajo. (2015). <em>Decreto 1072 de 2015: Decreto Único Reglamentario del Sector Trabajo (Libro 2, Parte 2, Título 4, Capítulo 6: SG-SST)</em>.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Ministerio del Trabajo. (2019). <em>Resolución 0312 de 2019: Estándares Mínimos del SG-SST</em>.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Servicio Nacional de Aprendizaje - SENA. (2026). <em>Componente Formativo: Legislación en medio ambiente, seguridad y salud en el trabajo</em>. Dirección de Formación Profesional.
    </li>
  </ul>

</body>
</html>
"""

html_file_path = os.path.join(DOCS_DIR, 'reporte_imprimible.html')
with open(html_file_path, 'w', encoding='utf-8') as f:
    f.write(html_content)
print(f"HTML generado en: {html_file_path}")

# Compilar PDF formal usando Google Chrome Headless
pdf_filename = 'GA8-220601501-AA2-EV01_Diagrama_Ishikawa_ATEL.pdf'
pdf_output_path = os.path.join(DOCS_DIR, pdf_filename)
pdf_entrega_path = os.path.join(ENTREGA_DIR, pdf_filename)

chrome_cmd = [
    'google-chrome',
    '--headless',
    '--disable-gpu',
    '--no-pdf-header-footer',
    f'--print-to-pdf={pdf_output_path}',
    html_file_path
]

print("Compilando PDF institucional con Google Chrome...")
res_chrome = subprocess.run(chrome_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
if res_chrome.returncode == 0 and os.path.exists(pdf_output_path):
    pdf_size_kb = os.path.getsize(pdf_output_path) / 1024
    print(f"PDF generado exitosamente ({pdf_size_kb:.1f} KB) en: {pdf_output_path}")
    shutil.copy2(pdf_output_path, pdf_entrega_path)
    print(f"PDF copiado a entrega Zajuna: {pdf_entrega_path}")
else:
    print(f"Error al generar PDF: {res_chrome.stderr.decode()}")

# Compilar Formato Word (DOCX) con LibreOffice Headless
docx_filename = 'GA8-220601501-AA2-EV01_Diagrama_Ishikawa_ATEL.docx'
docx_output_path = os.path.join(DOCS_DIR, docx_filename)
docx_entrega_path = os.path.join(ENTREGA_DIR, docx_filename)

libreoffice_cmd = [
    'libreoffice',
    '--headless',
    '--convert-to',
    'docx:MS Word 2007 XML',
    html_file_path,
    '--outdir',
    DOCS_DIR
]

print("Compilando formato Word (DOCX) con LibreOffice...")
res_lo = subprocess.run(libreoffice_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
generated_docx = os.path.join(DOCS_DIR, 'reporte_imprimible.docx')
if os.path.exists(generated_docx):
    if os.path.exists(docx_output_path):
        os.remove(docx_output_path)
    os.rename(generated_docx, docx_output_path)
    docx_size_kb = os.path.getsize(docx_output_path) / 1024
    print(f"DOCX generado exitosamente ({docx_size_kb:.1f} KB) en: {docx_output_path}")
    shutil.copy2(docx_output_path, docx_entrega_path)
    print(f"DOCX copiado a entrega Zajuna: {docx_entrega_path}")
