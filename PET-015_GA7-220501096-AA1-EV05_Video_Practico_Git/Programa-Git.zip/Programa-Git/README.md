# Programa-Git

Repositorio oficial para la práctica de versionamiento distribuido con Git y GitHub.

- **Institución:** Servicio Nacional de Aprendizaje (SENA)
- **Programa:** Análisis y Desarrollo de Software (ADSO) - Ficha 228118
- **Aprendiz:** Karen Yuliana Campo
- **Evidencia:** GA7-220501096-AA1-EV05 - Herramientas de versionamiento (GIT) instalada y configurada
