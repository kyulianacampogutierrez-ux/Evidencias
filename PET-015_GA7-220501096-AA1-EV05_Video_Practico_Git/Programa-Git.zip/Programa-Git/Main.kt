/**
 * Programa de demostración para el control de versiones con Git
 * Aprendiz: Karen Yuliana Campo - SENA ADSO Ficha 228118
 */
fun main() {
    println("==================================================")
    println("Bienvenido al Sistema de Gestión Programa-Git")
    println("Servicio Nacional de Aprendizaje (SENA)")
    println("Aprendiz: Karen Yuliana Campo")
    println("Ficha: 228118 - Popayán, Cauca")
    println("==================================================")
}
