#!/bin/bash
# ==============================================================================
# SCRIPT DE INICIO RÁPIDO PARA APP MÓVIL REACT NATIVE (EXPO METRO BUNDLER)
# Permite probar la app en tu celular físico mediante la app Expo Go
# Aprendiz: Karen Yuliana Campo | Ficha: 3186681 | ADSO CTPI Popayán
# ==============================================================================

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HOST_IP="192.168.20.21"

echo "=================================================================="
echo "🍕 PIZZERÍA BELLA ITALIA - SERVIDOR DE DESARROLLO MÓVIL (EXPO)"
echo "IP Local Host: $HOST_IP"
echo "Backend REST:  http://$HOST_IP:8085/api (Go + Fiber v2 + MongoDB)"
echo "=================================================================="
echo ""
echo "PASOS RÁPIDOS:"
echo "1. Conecta tu teléfono a la misma red Wi-Fi que este computador."
echo "2. Abre la app 'Expo Go' en tu teléfono (descárgala gratis de Play Store o App Store)."
echo "3. Escanea el código QR que se mostrará en pantalla."
echo ""

docker run -it --rm \
  --name sena-rn-dev \
  -v "$DIR":/app \
  -w /app \
  -p 8081:8081 \
  -e REACT_NATIVE_PACKAGER_HOSTNAME="$HOST_IP" \
  node:22-alpine npx expo start --lan --clear
