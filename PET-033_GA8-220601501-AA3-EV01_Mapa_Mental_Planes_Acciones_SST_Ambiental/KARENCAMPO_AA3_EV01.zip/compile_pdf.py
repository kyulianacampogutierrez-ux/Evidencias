#!/usr/bin/env python3
# ==============================================================================
# COMPILADOR DE MAPA MENTAL FORMAL PDF Y WORD (SENA ADSO GUÍA 8 - AA3-EV01)
# Evidencia: GA8-220601501-AA3-EV01 - Mapa mental respecto a los planes y acciones
# establecidos en el medio ambiente y SST
# Aprendiz: Karen Yuliana Campo | Ficha: 3186681 | CTPI Popayán - Regional Cauca
# ==============================================================================

import os
import subprocess
import shutil

BASE_DIR = '/home/danilo/Escritorio/Karen/SENA/CDE/Evidencias/PET-033_GA8-220601501-AA3-EV01_Mapa_Mental_Planes_Acciones_SST_Ambiental'
DOCS_DIR = os.path.join(BASE_DIR, 'docs')
DIAG_DIR = os.path.join(BASE_DIR, 'diagramas')
ENTREGA_DIR = '/home/danilo/Escritorio/Karen/SENA/ENTREGA_ZAJUNA_GA8-220601501-AA3-EV01'

os.makedirs(DOCS_DIR, exist_ok=True)
os.makedirs(ENTREGA_DIR, exist_ok=True)

mindmap_png = os.path.join(DIAG_DIR, 'mapa_mental_planes_acciones_sst_ambiental.png')
mindmap_svg = os.path.join(DIAG_DIR, 'mapa_mental_planes_acciones_sst_ambiental.svg')

# ------------------------------------------------------------------------------
# 1. GENERAR PDF DE EXACTAMENTE 1 HOJA HORIZONTAL (REQUISITO ESTRICTO GUÍA 8)
# ------------------------------------------------------------------------------
html_1page = f"""<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Mapa Mental Planes y Acciones SST y Ambiental - 1 Hoja | Karen Campo</title>
  <style>
    @page {{
      size: letter landscape;
      margin: 0;
    }}
    * {{
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }}
    body, html {{
      width: 100%;
      height: 100%;
      overflow: hidden;
      background: #f8fafc;
      display: flex;
      align-items: center;
      justify-content: center;
    }}
    .map-img {{
      width: 100vw;
      height: 100vh;
      object-fit: contain;
    }}
  </style>
</head>
<body>
  <img src="file://{mindmap_png}" alt="Mapa Mental Planes y Acciones SST y Ambiental" class="map-img">
</body>
</html>
"""

html_1page_path = os.path.join(DOCS_DIR, 'mapa_mental_1_hoja.html')
with open(html_1page_path, 'w', encoding='utf-8') as f:
    f.write(html_1page)

pdf_1page_name = 'GA8-220601501-AA3-EV01_Mapa_Mental_1_Hoja.pdf'
pdf_1page_output = os.path.join(DOCS_DIR, pdf_1page_name)
pdf_1page_entrega = os.path.join(ENTREGA_DIR, pdf_1page_name)

chrome_cmd_1page = [
    'google-chrome',
    '--headless',
    '--disable-gpu',
    '--no-pdf-header-footer',
    '--window-size=2400,1400',
    f'--print-to-pdf={pdf_1page_output}',
    html_1page_path
]

print("Compilando PDF de 1 Hoja Horizontal (Extensión exacta según Guía)...")
res_1p = subprocess.run(chrome_cmd_1page, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
if res_1p.returncode == 0 and os.path.exists(pdf_1page_output):
    p1_size_kb = os.path.getsize(pdf_1page_output) / 1024
    print(f"PDF 1 Hoja generado ({p1_size_kb:.1f} KB) en: {pdf_1page_output}")
    shutil.copy2(pdf_1page_output, pdf_1page_entrega)
    print(f"PDF 1 Hoja copiado a entrega Zajuna: {pdf_1page_entrega}")

# ------------------------------------------------------------------------------
# 2. GENERAR INFORME INSTITUCIONAL COMPLETO (PORTADA SENA + MAPA + DESGLOSE)
# ------------------------------------------------------------------------------
html_full = f"""<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Mapa Mental Planes y Acciones SST y Ambiental - GA8-AA3-EV01 | Karen Campo</title>
  <style>
    @page {{
      size: letter;
      margin: 1.8cm 1.6cm 1.8cm 1.6cm;
      @bottom-right {{
        content: counter(page);
      }}
    }}
    @page landscape-section {{
      size: letter landscape;
      margin: 1cm;
    }}
    * {{
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }}
    body {{
      font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
      color: #1e293b;
      line-height: 1.5;
      font-size: 9.5pt;
      background: #ffffff;
    }}
    .page-break {{
      page-break-before: always;
    }}
    
    /* PORTADA OFICIAL SENA */
    .cover {{
      height: 94vh;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      border: 3px solid #059669;
      padding: 35px 30px;
      background: linear-gradient(180deg, #f0fdf4 0%, #ffffff 100%);
      border-radius: 8px;
    }}
    .cover-header {{
      text-align: center;
      border-bottom: 2px solid #059669;
      padding-bottom: 18px;
    }}
    .cover-header h1 {{
      font-size: 19pt;
      color: #065f46;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-bottom: 6px;
    }}
    .cover-header h2 {{
      font-size: 13pt;
      color: #0f172a;
      font-weight: 600;
    }}
    .cover-header h3 {{
      font-size: 10pt;
      color: #64748b;
      margin-top: 4px;
    }}
    .cover-badge {{
      display: inline-block;
      background: #059669;
      color: white;
      padding: 4px 14px;
      border-radius: 20px;
      font-size: 9pt;
      font-weight: bold;
      margin-top: 10px;
    }}
    .cover-body {{
      text-align: center;
      margin: 20px 0;
    }}
    .cover-title {{
      font-size: 17pt;
      color: #0f172a;
      font-weight: 800;
      line-height: 1.3;
      margin-bottom: 15px;
    }}
    .cover-subtitle {{
      font-size: 11pt;
      color: #334155;
      max-width: 650px;
      margin: 0 auto 20px auto;
      line-height: 1.4;
    }}
    .cover-info-card {{
      background: #ffffff;
      border: 1px solid #cbd5e1;
      border-left: 5px solid #059669;
      border-radius: 6px;
      padding: 15px;
      display: inline-block;
      text-align: left;
      margin: 0 auto;
      min-width: 450px;
    }}
    .cover-info-row {{
      font-size: 9.5pt;
      margin-bottom: 6px;
    }}
    .cover-info-row:last-child {{
      margin-bottom: 0;
    }}
    .cover-info-label {{
      font-weight: bold;
      color: #065f46;
      display: inline-block;
      width: 150px;
    }}
    .cover-footer {{
      text-align: center;
      border-top: 1px solid #cbd5e1;
      padding-top: 15px;
      font-size: 9pt;
      color: #64748b;
    }}

    /* ENCABEZADOS Y TEXTO */
    .header-running {{
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #cbd5e1;
      padding-bottom: 4px;
      margin-bottom: 15px;
      font-size: 8pt;
      color: #64748b;
      text-transform: uppercase;
    }}
    h1.sec-title {{
      font-size: 13pt;
      color: #065f46;
      border-bottom: 2px solid #059669;
      padding-bottom: 4px;
      margin-top: 18px;
      margin-bottom: 10px;
      text-transform: uppercase;
      page-break-after: avoid;
    }}
    h2.subsec-title {{
      font-size: 11pt;
      color: #0f172a;
      margin-top: 12px;
      margin-bottom: 6px;
      border-left: 3px solid #059669;
      padding-left: 8px;
      page-break-after: avoid;
    }}
    p {{
      margin-bottom: 8px;
      text-align: justify;
    }}
    ul, ol {{
      margin-left: 20px;
      margin-bottom: 10px;
    }}
    li {{
      margin-bottom: 4px;
    }}

    /* TABLAS ESTILIZADAS */
    table {{
      width: 100%;
      border-collapse: collapse;
      margin: 12px 0;
      font-size: 8.5pt;
      page-break-inside: avoid;
    }}
    th {{
      background-color: #065f46;
      color: #ffffff;
      padding: 7px 8px;
      text-align: left;
      font-weight: 600;
      border: 1px solid #047857;
    }}
    td {{
      padding: 6px 8px;
      border: 1px solid #cbd5e1;
      vertical-align: top;
    }}
    tr:nth-child(even) {{
      background-color: #f8fafc;
    }}

    /* CAJAS DE INFORMACIÓN */
    .callout {{
      background-color: #f0fdf4;
      border: 1px solid #bbf7d0;
      border-left: 4px solid #059669;
      padding: 10px 14px;
      border-radius: 4px;
      margin: 10px 0;
      font-size: 9pt;
    }}
    .callout-title {{
      font-weight: bold;
      color: #065f46;
      margin-bottom: 4px;
    }}

    /* DIAGRAMAS */
    .diagram-container {{
      text-align: center;
      margin: 12px 0;
      page-break-inside: avoid;
    }}
    .diagram-img {{
      max-width: 100%;
      height: auto;
      border: 1px solid #cbd5e1;
      border-radius: 6px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.06);
    }}
    .diagram-caption {{
      font-size: 8pt;
      color: #64748b;
      margin-top: 5px;
      font-style: italic;
    }}
  </style>
</head>
<body>

  <!-- ==================== PORTADA ==================== -->
  <div class="cover">
    <div class="cover-header">
      <h1>Servicio Nacional de Aprendizaje - SENA</h1>
      <h2>Centro de Teleinformática y Producción Industrial (CTPI)</h2>
      <h3>Regional Cauca • Popayán</h3>
      <div class="cover-badge">PROGRAMA ADSO • FICHA 3186681</div>
    </div>

    <div class="cover-body">
      <div class="cover-title">
        MAPA MENTAL RESPECTO A LOS PLANES Y ACCIONES<br>
        ESTABLECIDOS EN EL MEDIO AMBIENTE Y SST
      </div>
      <div class="cover-subtitle">
        Desarrollo metodológico fundamentado en las leyes mnemotécnicas de Tony Buzan y el anexo del SENA ("Guia-para-hacer-mapa-mental.docx"). Análisis sistémico radial de planes y acciones bajo el Decreto 1072/2015 (SG-SST), Resolución 0312/2019, Decreto 1076/2015 (PIGA), Resolución 2184/2019 y articulación con el proyecto formativo Pizzería Gourmet Bella Italia Popayán.
      </div>

      <div class="cover-info-card">
        <div class="cover-info-row">
          <span class="cover-info-label">Evidencia:</span>
          <strong>GA8-220601501-AA3-EV01</strong>
        </div>
        <div class="cover-info-row">
          <span class="cover-info-label">Competencia:</span>
          <span>220601501 - Protección ambiental y SST</span>
        </div>
        <div class="cover-info-row">
          <span class="cover-info-label">Aprendiz:</span>
          <strong>Karen Yuliana Campo</strong>
        </div>
        <div class="cover-info-row">
          <span class="cover-info-label">Ficha Formativa:</span>
          <strong>3186681</strong>
        </div>
        <div class="cover-info-row">
          <span class="cover-info-label">Proyecto Formativo:</span>
          <span>Pizzería Gourmet Bella Italia Popayán</span>
        </div>
        <div class="cover-info-row">
          <span class="cover-info-label">Lugar y Fecha:</span>
          <span>Popayán, Cauca — Noviembre 2026</span>
        </div>
      </div>
    </div>

    <div class="cover-footer">
      Tecnología en Análisis y Desarrollo de Software • Modalidad Virtual<br>
      Sistema Integrado de Gestión y Autocontrol (SIGA-SENA)
    </div>
  </div>

  <div class="page-break"></div>

  <!-- ==================== MAPA MENTAL INTEGRADO ==================== -->
  <div class="header-running">
    <span>SENA CTPI Popayán • ADSO Ficha 3186681</span>
    <span>GA8-220601501-AA3-EV01: Mapa Mental Planes y Acciones SST y Ambiental</span>
  </div>

  <h1 class="sec-title">1. MAPA MENTAL: PLANES Y ACCIONES EN MEDIO AMBIENTE Y SST</h1>
  <p>
    El mapa mental estructurado a continuación aplica de manera rigurosa las pautas del anexo <em>"Guia-para-hacer-mapa-mental.docx"</em> y la metodología de <strong>Tony Buzan</strong>: nodo central protagónico de alto impacto, lectura radial en el sentido de las agujas del reloj (iniciando en el cuadrante superior derecho a las 12:00), ramas curvas orgánicas con código cromático por bifurcación, delimitación por nubes temáticas, palabras clave directas, iconografía mnemotécnica y el <strong>recuadro oficial de datos personales de la aprendiz en la esquina inferior derecha</strong>:
  </p>

  <div class="diagram-container">
    <img src="file://{mindmap_png}" alt="Mapa Mental Planes y Acciones SST y Ambiental" class="diagram-img">
    <div class="diagram-caption">Figura 1: Mapa mental analítico y mnemotécnico de Planes y Acciones en Medio Ambiente y SST (Metodología Tony Buzan / Guía SENA).</div>
  </div>

  <div class="callout">
    <div class="callout-title">Síntesis Metodológica de Tony Buzan Aplicada al Mapa Mental</div>
    <ul style="margin-bottom: 0;">
      <li><strong>Sentido Horario:</strong> Cuadrante 1 (Noreste - Verde) &rarr; Cuadrante 2 (Sureste - Cian) &rarr; Cuadrante 3 (Suroeste - Azul) &rarr; Cuadrante 4 (Noroeste - Ámbar).</li>
      <li><strong>Diferenciación Cromática:</strong> Una gama de color específica por bifurcación principal (Verde para PIGA, Cian para Acciones Ambientales, Azul para SG-SST y Ámbar para Acciones SST).</li>
      <li><strong>Jerarquía de Ramificaciones:</strong> Grosor orgánico decreciente desde el nodo central (14px) hacia las sub-ramas intermedias (8px) y terminales (4px).</li>
      <li><strong>Iconografía Asociativa:</strong> Uso de símbolos universales (plantas, reciclaje, cruz de seguridad, extintores, pantallas y ergonomía) para activar el hemisferio derecho.</li>
    </ul>
  </div>

  <div class="page-break"></div>

  <!-- ==================== DESGLOSE TÉCNICO ==================== -->
  <div class="header-running">
    <span>SENA CTPI Popayán • ADSO Ficha 3186681</span>
    <span>GA8-220601501-AA3-EV01: Mapa Mental Planes y Acciones SST y Ambiental</span>
  </div>

  <h1 class="sec-title">2. DESGLOSE TÉCNICO DE PLANES Y ACCIONES POR CUADRANTE RADIAL</h1>

  <h2 class="subsec-title">2.1. Cuadrante Noreste (Verde Esmeralda): Planes Ambientales (PIGA &amp; ISO 14001)</h2>
  <p>
    Sustentado en el <strong>Decreto 1076 de 2015</strong> y la norma <strong>ISO 14001:2015</strong>, este eje establece los programas de planeación ambiental organizacional:
  </p>
  <table>
    <thead>
      <tr>
        <th style="width: 28%;">Sub-Rama / Plan</th>
        <th style="width: 42%;">Acciones y Medidas de Intervención</th>
        <th style="width: 30%;">Sustento Normativo y Meta</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><strong>Uso Eficiente de Recursos</strong></td>
        <td>Transición a luminarias LED industriales, sensores PIR automáticos en áreas de tránsito y aireadores ahorradores de agua en griferías.</td>
        <td>Ley 1715 de 2014 / RETILAP. Meta: Reducción del 25% en consumo de kWh y 15% en m³ de agua.</td>
      </tr>
      <tr>
        <td><strong>Gestión Integral de Residuos</strong></td>
        <td>Implementación del código unificado de colores: Blanco (aprovechables secos), Verde (orgánicos compostables) y Negro (no aprovechables).</td>
        <td>Resolución 2184 de 2019. Meta: 80% de segregación correcta en la fuente.</td>
      </tr>
      <tr>
        <td><strong>Manejo de RESPEL</strong></td>
        <td>Acopio seguro bajo techo con suelo impermeabilizado y rotulado SGA para luminarias de mercurio agotadas, pilas y residuos electrónicos RAEE.</td>
        <td>Decreto 1076 de 2015. Meta: 100% de residuos peligrosos con certificado de gestor autorizado.</td>
      </tr>
      <tr>
        <td><strong>Huella de Carbono</strong></td>
        <td>Cálculo periódico de emisiones de GEI, fomento de la movilidad activa y jornadas de reforestación con especies nativas en la cuenca de Popayán.</td>
        <td>Política Nacional de Cambio Climático. Meta: Compensación del 30% de emisiones directas.</td>
      </tr>
    </tbody>
  </table>

  <h2 class="subsec-title">2.2. Cuadrante Sureste (Cian): Acciones de Cultura Ambiental y Economía Circular</h2>
  <table>
    <thead>
      <tr>
        <th style="width: 28%;">Eje Operativo</th>
        <th style="width: 42%;">Acción Práctica Implementada</th>
        <th style="width: 30%;">Beneficio Ecológico Territorial</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><strong>Compras Sostenibles</strong></td>
        <td>Adquisición de empaques biodegradables (bagazo de caña de azúcar y maíz) e insumos agrícolas de productores locales de Popayán y Timbío.</td>
        <td>Erradicación del poliestireno (icopor) y reducción de la huella de transporte logístico.</td>
      </tr>
      <tr>
        <td><strong>Economía Circular</strong></td>
        <td>Transformación de restos de masas y vegetales en abono orgánico de alta calidad mediante compostaje en fincas comunitarias aliadas.</td>
        <td>Cierre de ciclo de nutrientes y desvío de toneladas de residuos del relleno sanitario Los Picachos.</td>
      </tr>
      <tr>
        <td><strong>Reciclaje de Aceites (ACU)</strong></td>
        <td>Recolección hermética de aceites vegetales usados en bidones rotulados; entrega periódica para producción certificada de biodiésel.</td>
        <td>Cero vertimientos a la red de alcantarillado; protección de fuentes hídricas caucanas.</td>
      </tr>
      <tr>
        <td><strong>Estrategia Cero Papel</strong></td>
        <td>Digitalización de comandas mediante apps React Native, pantallas de cocina y facturación electrónica de la DIAN.</td>
        <td>Ahorro del 95% en papel térmico y modernización tecnológica del servicio.</td>
      </tr>
    </tbody>
  </table>

  <div class="page-break"></div>

  <!-- ==================== DESGLOSE SST ==================== -->
  <div class="header-running">
    <span>SENA CTPI Popayán • ADSO Ficha 3186681</span>
    <span>GA8-220601501-AA3-EV01: Mapa Mental Planes y Acciones SST y Ambiental</span>
  </div>

  <h2 class="subsec-title">2.3. Cuadrante Suroeste (Azul Real): Planes del Sistema de Gestión SST (Dec. 1072/2015)</h2>
  <table>
    <thead>
      <tr>
        <th style="width: 28%;">Plan Estructural</th>
        <th style="width: 42%;">Componentes Clave y Estrategias</th>
        <th style="width: 30%;">Marco Regulatorio Colombiano</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><strong>Plan de Trabajo Anual SST</strong></td>
        <td>Fijación de objetivos SMART, cronograma detallado de actividades y asignación obligatoria de recursos financieros por la gerencia.</td>
        <td>Decreto 1072 de 2015 (Art. 2.2.4.6.8) y Resolución 0312 de 2019. Meta: 100% de estándares cumplidos.</td>
      </tr>
      <tr>
        <td><strong>Plan Anual de Capacitación</strong></td>
        <td>Inducción y reinducción en riesgos del cargo, primeros auxilios, combate de incendios, autocuidado y manejo defensivo.</td>
        <td>Decreto 1072 de 2015 (Art. 2.2.4.6.11). Meta: Cobertura del 100% del personal evaluado (&ge; 90%).</td>
      </tr>
      <tr>
        <td><strong>Plan de Emergencias</strong></td>
        <td>Análisis de vulnerabilidad sísmica (falla de Popayán), rutas de evacuación NTC 1461, extintores ABC/K y simulacros anuales.</td>
        <td>Resolución 2400 de 1979 / Decreto 1072 de 2015. Meta: Tiempo de evacuación total &lt; 3 minutos.</td>
      </tr>
      <tr>
        <td><strong>Vigilancia Epidemiológica</strong></td>
        <td>PVE Visual (astinopia ante pantallas), PVE Biomecánico (túnel carpiano, lumbalgias) y PVE Psicosocial (batería MinTrabajo).</td>
        <td>Ley 1562 de 2012 / Dec. 1072/2015. Meta: Cero enfermedades laborales calificadas.</td>
      </tr>
    </tbody>
  </table>

  <h2 class="subsec-title">2.4. Cuadrante Noroeste (Ámbar): Acciones de Prevención y Control en SST</h2>
  <table>
    <thead>
      <tr>
        <th style="width: 28%;">Mecanismo de Control</th>
        <th style="width: 42%;">Acción Práctica en Puesto de Trabajo</th>
        <th style="width: 30%;">Impacto en Salud y Productividad</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><strong>Jerarquía de Controles</strong></td>
        <td>Priorización de controles de ingeniería (escaleras con 300 Lux, bandas rugosas y doble pasamanos) sobre el EPP básico.</td>
        <td>Guía Técnica Colombiana GTC 45. Reducción del riesgo de caídas de Nivel I a Nivel III.</td>
      </tr>
      <tr>
        <td><strong>Participación COPASST</strong></td>
        <td>Inspecciones planeadas de seguridad mensuales, buzón de reporte de actos/condiciones inseguras e investigación oportuna de incidentes.</td>
        <td>Resolución 2013 de 1986 y Dec. 1072/2015. Respuesta a reportes de peligro en &lt; 48 horas.</td>
      </tr>
      <tr>
        <td><strong>Ergonomía en Puesto</strong></td>
        <td>Sillas neumáticas ergonómicas con soporte lumbar, monitor a nivel ocular, teclado desacoplado y límites de carga (&le; 25kg H / 12.5kg M).</td>
        <td>Resolución 2400 de 1979. Erradicación de dorsolumbalgias en desarrollo de software y almacén.</td>
      </tr>
      <tr>
        <td><strong>Pausas Activas y Autocuidado</strong></td>
        <td>Sesiones obligatorias de pausas activas de 8 a 10 min cada 2 horas de programación continua (articulado con evidencia PET-008).</td>
        <td>Estimulación de la circulación sanguínea periférica, relajación muscular y descanso visual.</td>
      </tr>
    </tbody>
  </table>

  <h1 class="sec-title">3. ARTICULACIÓN CON EL PROYECTO FORMATIVO: PIZZERÍA GOURMET BELLA ITALIA POPAYÁN</h1>
  <div class="callout">
    <div class="callout-title">Aplicación Real en los Entornos del Restaurante y el Software</div>
    <ul style="margin-bottom: 0;">
      <li><strong>Cocina y Servicio:</strong> Clasificación de residuos orgánicos para compostaje en Timbío, acopio de aceites vegetales usados (ACU) en bidones plásticos certificados para refinamiento en biodiésel y erradicación total del icopor con empaques de bagazo de caña.</li>
      <li><strong>Bodega de Harina y Leña de Roble:</strong> Escaleras de acceso iluminadas a 300 luxes con pasamanos de acero inoxidable y bandas antideslizantes, prohibiendo la carga de sacos al hombro superiores a 25 kg mediante el uso de carretillas mecánicas.</li>
      <li><strong>Estación de Desarrollo de Software (Aprendiz Karen Campo):</strong> Puesto de programación ergonómico, descansos visuales según la regla 20-20-20 y dos rutinas diarias de pausas activas para salvaguardar la salud física durante el desarrollo del sistema informático.</li>
    </ul>
  </div>

  <h1 class="sec-title">4. CONCLUSIONES</h1>
  <ol>
    <li>El <strong>mapa mental</strong> formulado bajo las directrices de Tony Buzan y el SENA sintetiza la articulación entre los <strong>Planes formales</strong> y las <strong>Acciones operativas</strong>, garantizando que el SG-SST y el PIGA sean asimilados de forma rápida, visual y duradera.</li>
    <li>La correlación de las 4 ramas en sentido horario evidencia que la sostenibilidad ambiental y la protección ocupacional no son compartimentos estancos, sino dimensiones complementarias de una misma cultura organizacional orientada a la excelencia.</li>
    <li>La inclusión del recuadro formal en la <strong>esquina inferior derecha</strong> garantiza la trazabilidad institucional y el cumplimiento estricto de los términos de referencia de la Guía de Aprendizaje 8.</li>
  </ol>

  <h1 class="sec-title">5. REFERENCIAS BIBLIOGRÁFICAS (NORMAS APA 7MA EDICIÓN)</h1>
  <ul style="list-style-type: none; margin-left: 0;">
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Buzan, T. (1996). <em>El libro de los mapas mentales: Cómo utilizar al máximo las capacidades de la mente</em>. Ediciones Urano.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Buzan, T. (2019). <em>Mapas mentales (Edición española): La guía definitiva para aprender a utilizar la herramienta de pensamiento más efectiva jamás inventada</em>. Alienta Editorial.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Caffaro, A. (2017). <em>Mapas mentales y su incidencia en la comprensión lectora</em> [Tesis de pregrado, Universidad Rafael Landívar]. Recursos Bibliográficos URL.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      ICONTEC. (2012). <em>Guía Técnica Colombiana GTC 45: Guía para la identificación de los peligros y la valoración de los riesgos en seguridad y salud en el trabajo</em> (2da ed.).
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Ministerio de Ambiente y Desarrollo Sostenible. (2015). <em>Decreto 1076 de 2015: Decreto Único Reglamentario del Sector Ambiente</em>.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Ministerio de Ambiente y Desarrollo Sostenible. (2019). <em>Resolución 2184 de 2019: Adopción del código de colores para la separación de residuos sólidos en la fuente</em>.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Ministerio del Trabajo. (2015). <em>Decreto 1072 de 2015: Decreto Único Reglamentario del Sector Trabajo (Capítulo 6: SG-SST)</em>.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Ministerio del Trabajo. (2019). <em>Resolución 0312 de 2019: Estándares Mínimos del SG-SST</em>.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Servicio Nacional de Aprendizaje - SENA. (2020). <em>Guía del aprendiz: Estrategia de aprendizaje mapa mental</em>. Dirección de Formación Profesional.
    </li>
  </ul>

</body>
</html>
"""

html_full_path = os.path.join(DOCS_DIR, 'reporte_imprimible.html')
with open(html_full_path, 'w', encoding='utf-8') as f:
    f.write(html_full)

# Compilar PDF formal completo con Google Chrome Headless
pdf_full_name = 'GA8-220601501-AA3-EV01_Mapa_Mental_Planes_Acciones.pdf'
pdf_full_output = os.path.join(DOCS_DIR, pdf_full_name)
pdf_full_entrega = os.path.join(ENTREGA_DIR, pdf_full_name)

chrome_cmd_full = [
    'google-chrome',
    '--headless',
    '--disable-gpu',
    '--no-pdf-header-footer',
    f'--print-to-pdf={pdf_full_output}',
    html_full_path
]

print("Compilando PDF institucional completo con Google Chrome...")
res_full = subprocess.run(chrome_cmd_full, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
if res_full.returncode == 0 and os.path.exists(pdf_full_output):
    pfull_size_kb = os.path.getsize(pdf_full_output) / 1024
    print(f"PDF completo generado ({pfull_size_kb:.1f} KB) en: {pdf_full_output}")
    shutil.copy2(pdf_full_output, pdf_full_entrega)
    print(f"PDF completo copiado a entrega Zajuna: {pdf_full_entrega}")

# Compilar formato Word (DOCX) con LibreOffice Headless
docx_name = 'GA8-220601501-AA3-EV01_Mapa_Mental_Planes_Acciones.docx'
docx_output = os.path.join(DOCS_DIR, docx_name)
docx_entrega = os.path.join(ENTREGA_DIR, docx_name)

libreoffice_cmd = [
    'libreoffice',
    '--headless',
    '--convert-to',
    'docx:MS Word 2007 XML',
    html_full_path,
    '--outdir',
    DOCS_DIR
]

print("Compilando formato Word (DOCX) con LibreOffice...")
res_lo = subprocess.run(libreoffice_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
generated_docx = os.path.join(DOCS_DIR, 'reporte_imprimible.docx')
if os.path.exists(generated_docx):
    if os.path.exists(docx_output):
        os.remove(docx_output)
    os.rename(generated_docx, docx_output)
    docx_size_kb = os.path.getsize(docx_output) / 1024
    print(f"DOCX generado ({docx_size_kb:.1f} KB) en: {docx_output}")
    shutil.copy2(docx_output, docx_entrega)
    print(f"DOCX copiado a entrega Zajuna: {docx_entrega}")
