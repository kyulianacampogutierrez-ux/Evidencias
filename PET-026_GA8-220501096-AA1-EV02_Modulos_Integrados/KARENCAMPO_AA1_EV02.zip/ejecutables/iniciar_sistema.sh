#!/bin/bash
# ==============================================================================
# SCRIPT EJECUTABLE DE ARRANQUE DEL SISTEMA INTEGRADO
# Pizzería Bella Italia Popayán | SENA ADSO Ficha 228118
# ==============================================================================

echo "======================================================================"
echo " PIZZERÍA GOURMET BELLA ITALIA POPAYÁN - INICIO DEL SISTEMA INTEGRADO"
echo " Aprendiz: Karen Yuliana Campo | Ficha: 228118 | SENA CTPI Popayán"
echo "======================================================================"

command -v docker >/dev/null 2>&1 || { echo >&2 "[ERROR] Docker no está instalado o no se encuentra en el PATH."; exit 1; }

echo "[INFO] Iniciando servicios multi-contenedor mediante Docker Compose..."
docker compose up -d

echo "[INFO] Esperando inicialización de MongoDB y Backend Go (5 segundos)..."
sleep 5

echo "[INFO] Verificando estado de salud del backend..."
curl -s http://localhost:8085/health || echo "[ADVERTENCIA] El backend aún está iniciando..."

echo ""
echo "======================================================================"
echo " SERVICIOS DESPLEGADOS SATISFACTORIAMENTE:"
echo " - Frontend Web React:      http://localhost:5173"
echo " - Backend Go Fiber v2:     http://localhost:8085"
echo " - API Healthcheck:         http://localhost:8085/health"
echo " - MongoDB Community 6.0:   localhost:27017"
echo " - React Native Metro:      http://localhost:8081"
echo "======================================================================"
