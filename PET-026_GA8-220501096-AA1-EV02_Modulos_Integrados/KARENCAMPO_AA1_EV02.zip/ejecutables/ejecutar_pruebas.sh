#!/bin/bash
# ==============================================================================
# SCRIPT EJECUTABLE DE PRUEBAS AUTOMATIZADAS DEL SISTEMA INTEGRADO
# Pizzería Bella Italia Popayán | SENA ADSO Ficha 228118
# ==============================================================================

echo "======================================================================"
echo " EJECUCIÓN DE PRUEBAS TDD AUTOMATIZADAS - MÓDULOS INTEGRADOS"
echo " Aprendiz: Karen Yuliana Campo | Ficha: 228118 | SENA CTPI Popayán"
echo "======================================================================"

echo "[INFO] Ejecutando suite completa de 189 pruebas en contenedor aislado..."
docker run --rm -v /home/danilo/Escritorio/Karen/SENA:/sena -w /sena/CDE -e SENA_ROOT=/sena node:20-alpine node --test
