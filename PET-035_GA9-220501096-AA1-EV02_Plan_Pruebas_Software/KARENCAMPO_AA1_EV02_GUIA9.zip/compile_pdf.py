#!/usr/bin/env python3
# ==============================================================================
# COMPILADOR DE PLAN DE PRUEBAS DE SOFTWARE EN PDF Y WORD (SENA GUÍA 9 - AA1-EV02)
# Evidencia: GA9-220501096-AA1-EV02 - Realiza plan pruebas de software
# Aprendiz: Karen Yuliana Campo | Ficha: 3186681 | CTPI Popayán - Regional Cauca
# ==============================================================================

import os
import subprocess
import shutil

BASE_DIR = '/home/danilo/Escritorio/Karen/SENA/CDE/Evidencias/PET-035_GA9-220501096-AA1-EV02_Plan_Pruebas_Software'
DOCS_DIR = os.path.join(BASE_DIR, 'docs')
DIAG_DIR = os.path.join(BASE_DIR, 'diagramas')
ENTREGA_DIR = '/home/danilo/Escritorio/Karen/SENA/ENTREGA_ZAJUNA_GA9-220501096-AA1-EV02'

os.makedirs(DOCS_DIR, exist_ok=True)
os.makedirs(ENTREGA_DIR, exist_ok=True)

d1_path = os.path.join(DIAG_DIR, 'ciclo_vida_pruebas_software_ieee829.png')
d2_path = os.path.join(DIAG_DIR, 'arquitectura_ambientes_pruebas_docker.png')
d3_path = os.path.join(DIAG_DIR, 'cronograma_plan_pruebas_gantt.png')

html_content = f"""<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Plan de Pruebas de Software - GA9-AA1-EV02 | Karen Campo</title>
  <style>
    @page {{
      size: letter;
      margin: 1.8cm 1.6cm 1.8cm 1.6cm;
      @bottom-right {{
        content: counter(page);
      }}
    }}
    * {{
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }}
    body {{
      font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
      color: #1e293b;
      line-height: 1.5;
      font-size: 9.5pt;
      background: #ffffff;
    }}
    .page-break {{
      page-break-before: always;
    }}
    
    /* PORTADA OFICIAL SENA */
    .cover {{
      height: 94vh;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      border: 3px solid #059669;
      padding: 35px 30px;
      background: linear-gradient(180deg, #f0fdf4 0%, #ffffff 100%);
      border-radius: 8px;
    }}
    .cover-header {{
      text-align: center;
      border-bottom: 2px solid #059669;
      padding-bottom: 18px;
    }}
    .cover-header h1 {{
      font-size: 19pt;
      color: #065f46;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-bottom: 6px;
    }}
    .cover-header h2 {{
      font-size: 13pt;
      color: #0f172a;
      font-weight: 600;
    }}
    .cover-header h3 {{
      font-size: 10pt;
      color: #64748b;
      margin-top: 4px;
    }}
    .cover-badge {{
      display: inline-block;
      background: #059669;
      color: white;
      padding: 4px 14px;
      border-radius: 20px;
      font-size: 9pt;
      font-weight: bold;
      margin-top: 10px;
    }}
    .cover-body {{
      text-align: center;
      margin: 20px 0;
    }}
    .cover-title {{
      font-size: 18pt;
      color: #0f172a;
      font-weight: 800;
      line-height: 1.3;
      margin-bottom: 15px;
    }}
    .cover-subtitle {{
      font-size: 11pt;
      color: #334155;
      max-width: 650px;
      margin: 0 auto 20px auto;
      line-height: 1.4;
    }}
    .cover-info-card {{
      background: #ffffff;
      border: 1px solid #cbd5e1;
      border-left: 5px solid #059669;
      border-radius: 6px;
      padding: 15px;
      display: inline-block;
      text-align: left;
      margin: 0 auto;
      min-width: 450px;
    }}
    .cover-info-row {{
      font-size: 9.5pt;
      margin-bottom: 6px;
    }}
    .cover-info-row:last-child {{
      margin-bottom: 0;
    }}
    .cover-info-label {{
      font-weight: bold;
      color: #065f46;
      display: inline-block;
      width: 150px;
    }}
    .cover-footer {{
      text-align: center;
      border-top: 1px solid #cbd5e1;
      padding-top: 15px;
      font-size: 9pt;
      color: #64748b;
    }}

    /* ENCABEZADOS Y TEXTO */
    .header-running {{
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #cbd5e1;
      padding-bottom: 4px;
      margin-bottom: 15px;
      font-size: 8pt;
      color: #64748b;
      text-transform: uppercase;
    }}
    h1.sec-title {{
      font-size: 13pt;
      color: #065f46;
      border-bottom: 2px solid #059669;
      padding-bottom: 4px;
      margin-top: 18px;
      margin-bottom: 10px;
      text-transform: uppercase;
      page-break-after: avoid;
    }}
    h2.subsec-title {{
      font-size: 11pt;
      color: #0f172a;
      margin-top: 12px;
      margin-bottom: 6px;
      border-left: 3px solid #059669;
      padding-left: 8px;
      page-break-after: avoid;
    }}
    p {{
      margin-bottom: 8px;
      text-align: justify;
    }}
    ul, ol {{
      margin-left: 20px;
      margin-bottom: 10px;
    }}
    li {{
      margin-bottom: 4px;
    }}

    /* TABLAS ESTILIZADAS */
    table {{
      width: 100%;
      border-collapse: collapse;
      margin: 12px 0;
      font-size: 8.5pt;
      page-break-inside: avoid;
    }}
    th {{
      background-color: #065f46;
      color: #ffffff;
      padding: 7px 8px;
      text-align: left;
      font-weight: 600;
      border: 1px solid #047857;
    }}
    td {{
      padding: 6px 8px;
      border: 1px solid #cbd5e1;
      vertical-align: top;
    }}
    tr:nth-child(even) {{
      background-color: #f8fafc;
    }}

    /* CAJAS DE INFORMACIÓN */
    .callout {{
      background-color: #f0fdf4;
      border: 1px solid #bbf7d0;
      border-left: 4px solid #059669;
      padding: 10px 14px;
      border-radius: 4px;
      margin: 10px 0;
      font-size: 9pt;
    }}
    .callout-title {{
      font-weight: bold;
      color: #065f46;
      margin-bottom: 4px;
    }}

    /* DIAGRAMAS */
    .diagram-container {{
      text-align: center;
      margin: 14px 0;
      page-break-inside: avoid;
    }}
    .diagram-img {{
      max-width: 98%;
      height: auto;
      border: 1px solid #cbd5e1;
      border-radius: 6px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.06);
    }}
    .diagram-caption {{
      font-size: 8pt;
      color: #64748b;
      margin-top: 5px;
      font-style: italic;
    }}
  </style>
</head>
<body>

  <!-- ==================== PORTADA ==================== -->
  <div class="cover">
    <div class="cover-header">
      <h1>Servicio Nacional de Aprendizaje - SENA</h1>
      <h2>Centro de Teleinformática y Producción Industrial (CTPI)</h2>
      <h3>Regional Cauca • Popayán</h3>
      <div class="cover-badge">PROGRAMA ADSO • FICHA 3186681</div>
    </div>

    <div class="cover-body">
      <div class="cover-title">
        PLAN MAESTRO DE PRUEBAS DE SOFTWARE<br>
        (ESTÁNDAR INTERNACIONAL IEEE 829 / ISO 29119)
      </div>
      <div class="cover-subtitle">
        Planificación técnica, diseño de artefactos de prueba (RTM, casos de prueba y bug reports), definición de ambientes virtualizados en Docker, análisis de requerimientos contables y de seguridad, y cronograma de ejecución para la solución "Pizzería Gourmet Bella Italia Popayán".
      </div>

      <div class="cover-info-card">
        <div class="cover-info-row">
          <span class="cover-info-label">Evidencia:</span>
          <strong>GA9-220501096-AA1-EV02</strong>
        </div>
        <div class="cover-info-row">
          <span class="cover-info-label">Competencia:</span>
          <span>220501096 - Desarrollar la solución de software</span>
        </div>
        <div class="cover-info-row">
          <span class="cover-info-label">Aprendiz:</span>
          <strong>Karen Yuliana Campo</strong>
        </div>
        <div class="cover-info-row">
          <span class="cover-info-label">Ficha Formativa:</span>
          <strong>3186681</strong>
        </div>
        <div class="cover-info-row">
          <span class="cover-info-label">Proyecto Formativo:</span>
          <span>Pizzería Gourmet Bella Italia Popayán</span>
        </div>
        <div class="cover-info-row">
          <span class="cover-info-label">Lugar y Fecha:</span>
          <span>Popayán, Cauca — Noviembre 2026</span>
        </div>
      </div>
    </div>

    <div class="cover-footer">
      Tecnología en Análisis y Desarrollo de Software • Modalidad Virtual<br>
      Sistema Integrado de Gestión y Autocontrol (SIGA-SENA)
    </div>
  </div>

  <div class="page-break"></div>

  <!-- ==================== SECCIÓN 1 Y 2 ==================== -->
  <div class="header-running">
    <span>SENA CTPI Popayán • ADSO Ficha 3186681</span>
    <span>GA9-220501096-AA1-EV02: Plan Maestro de Pruebas de Software</span>
  </div>

  <h1 class="sec-title">1. INTRODUCCIÓN Y OBJETIVOS DE CALIDAD</h1>
  <p>
    El desarrollo de la plataforma tecnológica para la <strong>Pizzería Gourmet Bella Italia Popayán</strong> involucra la sincronización de microservicios backend en <strong>Go (Fiber v2)</strong>, bases de datos <strong>MongoDB</strong> y <strong>MariaDB</strong>, un frontend web reactivo en <strong>React/Vite</strong> y una aplicación móvil nativa en <strong>React Native</strong>. Para garantizar que cada módulo opere de manera fiable, segura y sin interrupciones en el servicio, se formula el presente **Plan Maestro de Pruebas de Software (Master Test Plan)** bajo los estándares internacionales <strong>IEEE 829-2008</strong> e <strong>ISO/IEC/IEEE 29119</strong>.
  </p>

  <div class="callout">
    <div class="callout-title">Objetivos Estratégicos del Plan de Pruebas</div>
    <ul style="margin-bottom: 0;">
      <li><strong>Exactitud Financiera y Tributaria:</strong> Certificar que la liquidación del Impuesto Nacional al Consumo (8%), los descuentos y los fletes zonales en Popayán operen con un margen de error del 0%.</li>
      <li><strong>Integridad y Seguridad de Datos:</strong> Prevenir brechas de seguridad mediante la validación de control de acceso RBAC y saneamiento contra inyecciones XSS y NoSQL.</li>
      <li><strong>Continuidad Operativa:</strong> Asegurar la reserva transaccional de stock de bodega y tiempos de respuesta de la API inferiores a 200 milisegundos en horas pico gastronómicas.</li>
    </ul>
  </div>

  <h1 class="sec-title">2. ANÁLISIS DE REQUERIMIENTOS: FUNCIONALIDADES EXISTENTES VS NUEVAS</h1>
  <table>
    <thead>
      <tr>
        <th style="width: 20%;">Categoría</th>
        <th style="width: 40%;">Funcionalidades Identificadas</th>
        <th style="width: 40%;">Estrategia de Prueba Planificada</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><strong>Funcionalidades Existentes</strong></td>
        <td>Autenticación básica de clientes, consulta pública del catálogo de pizzas gourmet y adición al carrito de compras.</td>
        <td>Pruebas de Regresión automáticas en cada build de Docker para verificar no degradación del servicio.</td>
      </tr>
      <tr>
        <td><strong>Nuevas Funcionalidades a Probar</strong></td>
        <td>
          1) Liquidación del Impoconsumo (8%) según Estatuto Tributario;<br>
          2) Tarifación zonal de domicilios en Popayán (Centro, Norte, Sur, Rural);<br>
          3) Motor de cupones gourmet promocionales;<br>
          4) Control de acceso por roles (Admin, Cocinero, Repartidor, Cliente);<br>
          5) Módulo KDS de cocina y control de stock transaccional en bodega.
        </td>
        <td>Pruebas Unitarias exhaustivas (TDD con <code>node:test</code>), Pruebas de Integración de APIs REST con <code>Newman</code> y Pruebas de Seguridad OWASP.</td>
      </tr>
    </tbody>
  </table>

  <!-- DIAGRAMA 1 -->
  <div class="diagram-container">
    <img src="file://{d1_path}" alt="Ciclo de Vida del Proceso de Pruebas IEEE 829" class="diagram-img">
    <div class="diagram-caption">Figura 1: Fases formales del proceso de pruebas bajo el estándar IEEE 829 y gobernanza de artefactos de registro.</div>
  </div>

  <div class="page-break"></div>

  <!-- ==================== SECCIÓN 3 Y 4 ==================== -->
  <div class="header-running">
    <span>SENA CTPI Popayán • ADSO Ficha 3186681</span>
    <span>GA9-220501096-AA1-EV02: Plan Maestro de Pruebas de Software</span>
  </div>

  <h1 class="sec-title">3. ESTRATEGIA, ENFOQUE Y CRITERIOS FORMALES DE PRUEBA</h1>
  <p>
    El plan adopta una estrategia multinivel piramidal sustentada en los siguientes criterios de compuerta (**Quality Gates**):
  </p>

  <table>
    <thead>
      <tr>
        <th style="width: 25%;">Criterio de Compuerta</th>
        <th style="width: 75%;">Condiciones Técnicas Exigidas</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><strong>Criterios de Inicio (Entry)</strong></td>
        <td>Código fuente compilado sin errores sintácticos; contenedores Docker de MongoDB y Backend en estado <code>healthy</code>; Matriz de Trazabilidad RTM aprobada.</td>
      </tr>
      <tr>
        <td><strong>Criterios de Suspensión</strong></td>
        <td>Defecto de severidad Bloqueante que impida la ejecución de más del 30% de los casos de prueba; caída irreversible de la base de datos de pruebas.</td>
      </tr>
      <tr>
        <td><strong>Criterios de Reanudación</strong></td>
        <td>Despliegue del parche correctivo verificado en pruebas unitarias y confirmación de estabilidad del entorno por QA.</td>
      </tr>
      <tr>
        <td><strong>Criterios de Aceptación (Exit)</strong></td>
        <td><strong>100% de casos críticos ejecutados</strong>; tasa de aprobación global &ge; 98% (100% en cálculos contables); <strong>cero defectos Bloqueantes o Altos abiertos</strong>.</td>
      </tr>
    </tbody>
  </table>

  <h1 class="sec-title">4. AMBIENTES DE TRABAJO REQUERIDOS (SOFTWARE, HARDWARE Y DOCKER)</h1>
  <p>
    Para evitar discrepancias entre el entorno de desarrollo y producción, todas las pruebas se ejecutan en una arquitectura virtualizada orquestada con <strong>Docker Compose</strong>:
  </p>

  <!-- DIAGRAMA 2 -->
  <div class="diagram-container">
    <img src="file://{d2_path}" alt="Arquitectura de Ambientes de Prueba Docker" class="diagram-img">
    <div class="diagram-caption">Figura 2: Ecosistema dockerizado de pruebas de la Pizzería Bella Italia Popayán.</div>
  </div>

  <div class="page-break"></div>

  <!-- ==================== SECCIÓN 5 Y 6 ==================== -->
  <div class="header-running">
    <span>SENA CTPI Popayán • ADSO Ficha 3186681</span>
    <span>GA9-220501096-AA1-EV02: Plan Maestro de Pruebas de Software</span>
  </div>

  <h1 class="sec-title">5. METODOLOGÍA, CRONOGRAMA Y PLANIFICACIÓN TEMPORAL</h1>
  <p>
    El plan de pruebas se ejecuta a lo largo de <strong>cuatro semanas</strong> mediante ciclos ágiles TDD:
  </p>

  <!-- DIAGRAMA 3 -->
  <div class="diagram-container">
    <img src="file://{d3_path}" alt="Cronograma de Ejecución del Plan de Pruebas" class="diagram-img">
    <div class="diagram-caption">Figura 3: Cronograma de ejecución temporal del plan de pruebas (Gantt por semanas).</div>
  </div>

  <h1 class="sec-title">6. DISEÑO DE ARTEFACTOS E INSTRUMENTOS DE REGISTRO</h1>
  <p>
    El plan implementa tres artefactos formales de registro disponibles en el repositorio institucional:
  </p>
  <ul>
    <li><strong>Especificación de Casos de Prueba (IEEE 829):</strong> Plantilla estandarizada con identificador, módulo, precondiciones, pasos detallados, payload JSON de prueba y resultados esperados.</li>
    <li><strong>Registro y Seguimiento de Defectos (Bug Tracking Report):</strong> Formato para documentar incidencias clasificadas por severidad (Bloqueante, Alta, Media, Baja), pasos reproducibles y verificación de re-test.</li>
    <li><strong>Matriz de Trazabilidad de Requisitos (RTM):</strong> Mapeo integral que vincula los 12 Requisitos Funcionales (RF-01 a RF-12) y Requisitos No Funcionales con sus respectivos casos de prueba, garantizando una **cobertura del 100%**.</li>
  </ul>

  <h1 class="sec-title">7. GESTIÓN DE RIESGOS Y PLANES DE CONTINGENCIA</h1>
  <table>
    <thead>
      <tr>
        <th style="width: 25%;">Riesgo Identificado</th>
        <th style="width: 15%;">Probabilidad</th>
        <th style="width: 15%;">Impacto</th>
        <th style="width: 45%;">Plan de Mitigación y Contingencia</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Retraso en endpoints del backend Go</td>
        <td>Media</td>
        <td>Alto</td>
        <td>Uso de mocks y stubs tempranos para no bloquear las pruebas unitarias del frontend.</td>
      </tr>
      <tr>
        <td>Datos corruptos en MongoDB de pruebas</td>
        <td>Baja</td>
        <td>Alto</td>
        <td>Scripts automáticos de sembrado (seeders) que restauran la base de datos antes de cada ejecución.</td>
      </tr>
      <tr>
        <td>Falsos positivos por latencia de red</td>
        <td>Media</td>
        <td>Medio</td>
        <td>Configuración de timeouts elásticos y políticas de reintento automático en peticiones HTTP.</td>
      </tr>
    </tbody>
  </table>

  <h1 class="sec-title">8. CONCLUSIONES</h1>
  <ol>
    <li>El <strong>Plan Maestro de Pruebas de Software</strong> proporciona una estructura científica y predecible que reduce drásticamente los defectos en producción y garantiza la exactitud contable de la pizzería.</li>
    <li>La adopción del estándar <strong>IEEE 829</strong> unifica la terminología, los formatos de registro y los criterios de compuerta entre los desarrolladores y evaluadores del SENA.</li>
    <li>La orquestación de ambientes mediante <strong>Docker Compose</strong> asegura que las pruebas sean 100% reproducibles, independientes del sistema operativo anfitrión y aptas para pipelines de integración continua.</li>
  </ol>

  <h1 class="sec-title">9. REFERENCIAS BIBLIOGRÁFICAS (NORMAS APA 7MA EDICIÓN)</h1>
  <ul style="list-style-type: none; margin-left: 0;">
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      IEEE Computer Society. (2008). <em>IEEE Standard for Software and System Test Documentation</em> (IEEE Std 829-2008). Institute of Electrical and Electronics Engineers.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      International Organization for Standardization. (2013). <em>ISO/IEC/IEEE 29119-1: Software and systems engineering — Software testing — Part 1: Concepts and definitions</em>. ISO.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      International Organization for Standardization. (2013). <em>ISO/IEC/IEEE 29119-3: Software and systems engineering — Software testing — Part 3: Test documentation</em>. ISO.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Pressman, R. S., & Maxim, B. R. (2020). <em>Software Engineering: A Practitioner's Approach</em> (9th ed.). McGraw-Hill Education.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Servicio Nacional de Aprendizaje - SENA. (2026). <em>Componente Formativo: Las pruebas de software</em>. Dirección de Formación Profesional.
    </li>
    <li style="margin-bottom: 6px; text-indent: -20px; margin-left: 20px;">
      Sommerville, I. (2016). <em>Software Engineering</em> (10th ed.). Pearson Education.
    </li>
  </ul>

</body>
</html>
"""

html_file_path = os.path.join(DOCS_DIR, 'reporte_imprimible.html')
with open(html_file_path, 'w', encoding='utf-8') as f:
    f.write(html_content)
print(f"HTML generado en: {html_file_path}")

# Compilar PDF formal usando Google Chrome Headless
pdf_filename = 'GA9-220501096-AA1-EV02_Plan_Pruebas_Software.pdf'
pdf_output_path = os.path.join(DOCS_DIR, pdf_filename)
pdf_entrega_path = os.path.join(ENTREGA_DIR, pdf_filename)

chrome_cmd = [
    'google-chrome',
    '--headless',
    '--disable-gpu',
    '--no-pdf-header-footer',
    f'--print-to-pdf={pdf_output_path}',
    html_file_path
]

print("Compilando PDF institucional con Google Chrome...")
res_chrome = subprocess.run(chrome_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
if res_chrome.returncode == 0 and os.path.exists(pdf_output_path):
    pdf_size_kb = os.path.getsize(pdf_output_path) / 1024
    print(f"PDF generado exitosamente ({pdf_size_kb:.1f} KB) en: {pdf_output_path}")
    shutil.copy2(pdf_output_path, pdf_entrega_path)
    print(f"PDF copiado a entrega Zajuna: {pdf_entrega_path}")
else:
    print(f"Error al generar PDF: {res_chrome.stderr.decode()}")

# Compilar Formato Word (DOCX) con LibreOffice Headless
docx_filename = 'GA9-220501096-AA1-EV02_Plan_Pruebas_Software.docx'
docx_output_path = os.path.join(DOCS_DIR, docx_filename)
docx_entrega_path = os.path.join(ENTREGA_DIR, docx_filename)

libreoffice_cmd = [
    'libreoffice',
    '--headless',
    '--convert-to',
    'docx:MS Word 2007 XML',
    html_file_path,
    '--outdir',
    DOCS_DIR
]

print("Compilando formato Word (DOCX) con LibreOffice...")
res_lo = subprocess.run(libreoffice_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
generated_docx = os.path.join(DOCS_DIR, 'reporte_imprimible.docx')
if os.path.exists(generated_docx):
    if os.path.exists(docx_output_path):
        os.remove(docx_output_path)
    os.rename(generated_docx, docx_output_path)
    docx_size_kb = os.path.getsize(docx_output_path) / 1024
    print(f"DOCX generado exitosamente ({docx_size_kb:.1f} KB) en: {docx_output_path}")
    shutil.copy2(docx_output_path, docx_entrega_path)
    print(f"DOCX copiado a entrega Zajuna: {docx_entrega_path}")
