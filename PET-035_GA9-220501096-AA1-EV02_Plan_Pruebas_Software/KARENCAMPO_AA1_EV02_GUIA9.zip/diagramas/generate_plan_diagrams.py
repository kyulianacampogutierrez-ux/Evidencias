#!/usr/bin/env python3
# ==============================================================================
# GENERADOR DE DIAGRAMAS DEL PLAN DE PRUEBAS DE SOFTWARE (IEEE 829)
# PROYECTO: PIZZERÍA GOURMET BELLA ITALIA POPAYÁN
# EVIDENCIA: GA9-220501096-AA1-EV02
# ==============================================================================

import os
import subprocess

BASE_DIR = '/home/danilo/Escritorio/Karen/SENA/CDE/Evidencias/PET-035_GA9-220501096-AA1-EV02_Plan_Pruebas_Software'
DIAG_DIR = os.path.join(BASE_DIR, 'diagramas')
os.makedirs(DIAG_DIR, exist_ok=True)

# ------------------------------------------------------------------------------
# DIAGRAMA 1: CICLO DE VIDA DEL PROCESO DE PRUEBAS (IEEE 829 / ISO 29119)
# ------------------------------------------------------------------------------
svg_d1 = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 650" width="1200" height="650" style="background:#ffffff; font-family:'Segoe UI', system-ui, sans-serif;">
  <defs>
    <linearGradient id="g1" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#065f46"/><stop offset="100%" stop-color="#059669"/></linearGradient>
    <linearGradient id="g2" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#0369a1"/><stop offset="100%" stop-color="#0284c7"/></linearGradient>
    <linearGradient id="g3" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#4338ca"/><stop offset="100%" stop-color="#6366f1"/></linearGradient>
    <linearGradient id="g4" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#b45309"/><stop offset="100%" stop-color="#f59e0b"/></linearGradient>
    <linearGradient id="g5" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#be123c"/><stop offset="100%" stop-color="#f43f5e"/></linearGradient>
    <linearGradient id="g6" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#047857"/><stop offset="100%" stop-color="#10b981"/></linearGradient>
    <filter id="shadow" x="-5%" y="-5%" width="110%" height="115%"><feDropShadow dx="2" dy="4" stdDeviation="4" flood-opacity="0.12"/></filter>
  </defs>

  <!-- ENCABEZADO -->
  <rect x="20" y="20" width="1160" height="60" rx="8" fill="#f8fafc" stroke="#cbd5e1"/>
  <text x="40" y="55" font-size="18" font-weight="bold" fill="#065f46">CICLO DE VIDA DEL PLAN DE PRUEBAS DE SOFTWARE (ESTÁNDAR IEEE 829 / ISO 29119)</text>
  <text x="1150" y="55" font-size="12" font-weight="bold" fill="#64748b" text-anchor="end">BELLA ITALIA POPAYÁN</text>

  <!-- FASE 1 -->
  <g filter="url(#shadow)">
    <rect x="50" y="120" width="160" height="200" rx="10" fill="url(#g1)"/>
    <circle cx="130" cy="165" r="24" fill="#ffffff" opacity="0.2"/>
    <text x="130" y="172" font-size="20" text-anchor="middle" fill="#ffffff">📋</text>
    <text x="130" y="210" font-size="13" font-weight="bold" fill="#ffffff" text-anchor="middle">FASE 1</text>
    <text x="130" y="230" font-size="14" font-weight="800" fill="#ffffff" text-anchor="middle">PLANIFICACIÓN</text>
    <text x="130" y="260" font-size="10" fill="#d1fae5" text-anchor="middle">• Alcance y Objetivos</text>
    <text x="130" y="278" font-size="10" fill="#d1fae5" text-anchor="middle">• Asignación Recursos</text>
    <text x="130" y="296" font-size="10" fill="#d1fae5" text-anchor="middle">• Matriz de Riesgos</text>
  </g>

  <!-- FLECHA 1-2 -->
  <path d="M 220 220 L 235 220" stroke="#059669" stroke-width="4" />
  <polygon points="235,220 225,214 225,226" fill="#059669"/>

  <!-- FASE 2 -->
  <g filter="url(#shadow)">
    <rect x="245" y="120" width="160" height="200" rx="10" fill="url(#g2)"/>
    <circle cx="325" cy="165" r="24" fill="#ffffff" opacity="0.2"/>
    <text x="325" y="172" font-size="20" text-anchor="middle" fill="#ffffff">✏️</text>
    <text x="325" y="210" font-size="13" font-weight="bold" fill="#ffffff" text-anchor="middle">FASE 2</text>
    <text x="325" y="230" font-size="14" font-weight="800" fill="#ffffff" text-anchor="middle">DISEÑO Y ANÁLISIS</text>
    <text x="325" y="260" font-size="10" fill="#e0f2fe" text-anchor="middle">• Casos de Prueba (CP)</text>
    <text x="325" y="278" font-size="10" fill="#e0f2fe" text-anchor="middle">• Matriz RTM</text>
    <text x="325" y="296" font-size="10" fill="#e0f2fe" text-anchor="middle">• Datos de Prueba (JSON)</text>
  </g>

  <!-- FLECHA 2-3 -->
  <polygon points="430,220 420,214 420,226" fill="#0284c7"/>

  <!-- FASE 3 -->
  <g filter="url(#shadow)">
    <rect x="440" y="120" width="160" height="200" rx="10" fill="url(#g3)"/>
    <circle cx="520" cy="165" r="24" fill="#ffffff" opacity="0.2"/>
    <text x="520" y="172" font-size="20" text-anchor="middle" fill="#ffffff">🐳</text>
    <text x="520" y="210" font-size="13" font-weight="bold" fill="#ffffff" text-anchor="middle">FASE 3</text>
    <text x="520" y="230" font-size="14" font-weight="800" fill="#ffffff" text-anchor="middle">ENTORNO &amp; PREP.</text>
    <text x="520" y="260" font-size="10" fill="#e0e7ff" text-anchor="middle">• Contenedores Docker</text>
    <text x="520" y="278" font-size="10" fill="#e0e7ff" text-anchor="middle">• Base Datos MongoDB</text>
    <text x="520" y="296" font-size="10" fill="#e0e7ff" text-anchor="middle">• Mocking y Fixtures</text>
  </g>

  <!-- FLECHA 3-4 -->
  <polygon points="625,220 615,214 615,226" fill="#6366f1"/>

  <!-- FASE 4 -->
  <g filter="url(#shadow)">
    <rect x="635" y="120" width="160" height="200" rx="10" fill="url(#g4)"/>
    <circle cx="715" cy="165" r="24" fill="#ffffff" opacity="0.2"/>
    <text x="715" y="172" font-size="20" text-anchor="middle" fill="#ffffff">🚀</text>
    <text x="715" y="210" font-size="13" font-weight="bold" fill="#ffffff" text-anchor="middle">FASE 4</text>
    <text x="715" y="230" font-size="14" font-weight="800" fill="#ffffff" text-anchor="middle">EJECUCIÓN TDD</text>
    <text x="715" y="260" font-size="10" fill="#fef3c7" text-anchor="middle">• Unitarias (node:test)</text>
    <text x="715" y="278" font-size="10" fill="#fef3c7" text-anchor="middle">• Integración REST API</text>
    <text x="715" y="296" font-size="10" fill="#fef3c7" text-anchor="middle">• Seguridad &amp; Carga</text>
  </g>

  <!-- FLECHA 4-5 -->
  <polygon points="820,220 810,214 810,226" fill="#f59e0b"/>

  <!-- FASE 5 -->
  <g filter="url(#shadow)">
    <rect x="830" y="120" width="160" height="200" rx="10" fill="url(#g5)"/>
    <circle cx="910" cy="165" r="24" fill="#ffffff" opacity="0.2"/>
    <text x="910" y="172" font-size="20" text-anchor="middle" fill="#ffffff">🐛</text>
    <text x="910" y="210" font-size="13" font-weight="bold" fill="#ffffff" text-anchor="middle">FASE 5</text>
    <text x="910" y="230" font-size="14" font-weight="800" fill="#ffffff" text-anchor="middle">DEFECT TRACKING</text>
    <text x="910" y="260" font-size="10" fill="#ffe4e6" text-anchor="middle">• Registro de Bugs</text>
    <text x="910" y="278" font-size="10" fill="#ffe4e6" text-anchor="middle">• Clasificación Severidad</text>
    <text x="910" y="296" font-size="10" fill="#ffe4e6" text-anchor="middle">• Re-test y Verificación</text>
  </g>

  <!-- FLECHA 5-6 -->
  <polygon points="1015,220 1005,214 1005,226" fill="#f43f5e"/>

  <!-- FASE 6 -->
  <g filter="url(#shadow)">
    <rect x="1025" y="120" width="140" height="200" rx="10" fill="url(#g6)"/>
    <circle cx="1095" cy="165" r="24" fill="#ffffff" opacity="0.2"/>
    <text x="1095" y="172" font-size="20" text-anchor="middle" fill="#ffffff">📊</text>
    <text x="1095" y="210" font-size="13" font-weight="bold" fill="#ffffff" text-anchor="middle">FASE 6</text>
    <text x="1095" y="230" font-size="14" font-weight="800" fill="#ffffff" text-anchor="middle">CIERRE &amp; SQA</text>
    <text x="1095" y="260" font-size="10" fill="#d1fae5" text-anchor="middle">• Informe Final</text>
    <text x="1095" y="278" font-size="10" fill="#d1fae5" text-anchor="middle">• Tasa Éxito 100%</text>
    <text x="1095" y="296" font-size="10" fill="#d1fae5" text-anchor="middle">• Pase a Producción</text>
  </g>

  <!-- SECCIÓN INFERIOR: ARTEFACTOS Y GOBERNANZA -->
  <rect x="50" y="360" width="1115" height="250" rx="12" fill="#f8fafc" stroke="#cbd5e1" stroke-width="1.5"/>
  <text x="80" y="395" font-size="14" font-weight="bold" fill="#0f172a">ARTEFACTOS Y GOBERNANZA DEL PLAN DE PRUEBAS DE SOFTWARE</text>

  <rect x="80" y="420" width="320" height="160" rx="8" fill="#ffffff" stroke="#e2e8f0" filter="url(#shadow)"/>
  <text x="100" y="450" font-size="12" font-weight="bold" fill="#059669">📄 ESPECIFICACIÓN DE CASOS (IEEE 829)</text>
  <text x="100" y="475" font-size="11" fill="#475569">• ID único, módulo y precondiciones</text>
  <text x="100" y="495" font-size="11" fill="#475569">• Pasos detallados y Test Data (JSON)</text>
  <text x="100" y="515" font-size="11" fill="#475569">• Resultados esperados vs obtenidos</text>
  <text x="100" y="535" font-size="11" fill="#475569">• Criterio de pase/falla estricto</text>

  <rect x="440" y="420" width="320" height="160" rx="8" fill="#ffffff" stroke="#e2e8f0" filter="url(#shadow)"/>
  <text x="460" y="450" font-size="12" font-weight="bold" fill="#0284c7">🔍 MATRIZ DE TRAZABILIDAD (RTM)</text>
  <text x="460" y="475" font-size="11" fill="#475569">• Vinculación RF-XX con Historias de Usuario</text>
  <text x="460" y="495" font-size="11" fill="#475569">• Mapeo 1 a N con casos de prueba</text>
  <text x="460" y="515" font-size="11" fill="#475569">• Garantía de 100% de cobertura de código</text>
  <text x="460" y="535" font-size="11" fill="#475569">• Control de cambios y alcance</text>

  <rect x="800" y="420" width="335" height="160" rx="8" fill="#ffffff" stroke="#e2e8f0" filter="url(#shadow)"/>
  <text x="820" y="450" font-size="12" font-weight="bold" fill="#be123c">🛑 GESTIÓN DE INCIDENCIAS (BUG REPORT)</text>
  <text x="820" y="475" font-size="11" fill="#475569">• Clasificación de Severidad (Bloqueante, Alta, Media)</text>
  <text x="820" y="495" font-size="11" fill="#475569">• Pasos reproducibles y logs de consola</text>
  <text x="820" y="515" font-size="11" fill="#475569">• Ciclo: New -> Assigned -> Fixed -> Closed</text>
  <text x="820" y="535" font-size="11" fill="#475569">• Cero bugs críticos como criterio de aceptación</text>
</svg>"""

# ------------------------------------------------------------------------------
# DIAGRAMA 2: ARQUITECTURA DE AMBIENTES DE PRUEBA DOCKER
# ------------------------------------------------------------------------------
svg_d2 = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 650" width="1200" height="650" style="background:#ffffff; font-family:'Segoe UI', system-ui, sans-serif;">
  <defs>
    <filter id="shadow2" x="-5%" y="-5%" width="110%" height="115%"><feDropShadow dx="2" dy="4" stdDeviation="4" flood-opacity="0.12"/></filter>
  </defs>

  <rect x="20" y="20" width="1160" height="60" rx="8" fill="#f8fafc" stroke="#cbd5e1"/>
  <text x="40" y="55" font-size="18" font-weight="bold" fill="#065f46">ARQUITECTURA DE AMBIENTES DE PRUEBA ORQUESTADOS (DOCKER COMPOSE)</text>
  <text x="1150" y="55" font-size="12" font-weight="bold" fill="#64748b" text-anchor="end">SENA CTPI • ADSO 3186681</text>

  <!-- CONTENEDOR PRINCIPAL DOCKER COMPOSE -->
  <rect x="40" y="100" width="1120" height="510" rx="14" fill="#f1f5f9" stroke="#94a3b8" stroke-width="2" stroke-dasharray="6 6"/>
  <rect x="60" y="115" width="280" height="32" rx="6" fill="#0284c7"/>
  <text x="200" y="136" font-size="13" font-weight="bold" fill="#ffffff" text-anchor="middle">🐳 RED DOCKER AISLADA (sena-net)</text>

  <!-- SERVICIO 1: TEST RUNNER -->
  <g filter="url(#shadow2)">
    <rect x="80" y="170" width="310" height="190" rx="10" fill="#ffffff" stroke="#059669" stroke-width="2"/>
    <rect x="80" y="170" width="310" height="35" rx="10" fill="#059669"/>
    <rect x="80" y="190" width="310" height="15" fill="#059669"/>
    <text x="235" y="194" font-size="13" font-weight="bold" fill="#ffffff" text-anchor="middle">node-test-runner (Tester Core)</text>
    <text x="100" y="230" font-size="11" fill="#334155">• <strong>Imagen:</strong> node:20-alpine</text>
    <text x="100" y="250" font-size="11" fill="#334155">• <strong>Framework:</strong> node:test nativo &amp; assert</text>
    <text x="100" y="270" font-size="11" fill="#334155">• <strong>Utilidades:</strong> Newman CLI, Supertest</text>
    <text x="100" y="290" font-size="11" fill="#334155">• <strong>Volumen:</strong> /sena/CDE montado</text>
    <text x="100" y="310" font-size="11" fill="#334155">• <strong>Ejecución:</strong> TDD unitario &amp; integración</text>
    <text x="100" y="335" font-size="11" font-weight="bold" fill="#059669">ESTADO: HEALTHY (Tiempo: 156 ms)</text>
  </g>

  <!-- SERVICIO 2: BACKEND GO FIBER -->
  <g filter="url(#shadow2)">
    <rect x="440" y="170" width="320" height="190" rx="10" fill="#ffffff" stroke="#0284c7" stroke-width="2"/>
    <rect x="440" y="170" width="320" height="35" rx="10" fill="#0284c7"/>
    <rect x="440" y="190" width="320" height="15" fill="#0284c7"/>
    <text x="600" y="194" font-size="13" font-weight="bold" fill="#ffffff" text-anchor="middle">backend-go-api (Puerto 8085)</text>
    <text x="460" y="230" font-size="11" fill="#334155">• <strong>Imagen:</strong> golang:1.22-alpine</text>
    <text x="460" y="250" font-size="11" fill="#334155">• <strong>Framework:</strong> Go Fiber v2 REST</text>
    <text x="460" y="270" font-size="11" fill="#334155">• <strong>Endpoints:</strong> /auth, /pizzas, /pedidos, /health</text>
    <text x="460" y="290" font-size="11" fill="#334155">• <strong>Seguridad:</strong> JWT Middleware &amp; RBAC</text>
    <text x="460" y="310" font-size="11" fill="#334155">• <strong>Conexión:</strong> mongodb://mongodb:27017</text>
    <text x="460" y="335" font-size="11" font-weight="bold" fill="#0284c7">ESTADO: RUNNING (Latencia &lt; 15 ms)</text>
  </g>

  <!-- SERVICIO 3: BASE DE DATOS MONGODB -->
  <g filter="url(#shadow2)">
    <rect x="810" y="170" width="320" height="190" rx="10" fill="#ffffff" stroke="#10b981" stroke-width="2"/>
    <rect x="810" y="170" width="320" height="35" rx="10" fill="#10b981"/>
    <rect x="810" y="190" width="320" height="15" fill="#10b981"/>
    <text x="970" y="194" font-size="13" font-weight="bold" fill="#ffffff" text-anchor="middle">mongodb-pizzeria (Puerto 27017)</text>
    <text x="830" y="230" font-size="11" fill="#334155">• <strong>Imagen:</strong> mongo:7.0-jammy</text>
    <text x="830" y="250" font-size="11" fill="#334155">• <strong>Base de Datos:</strong> pizzeria_db</text>
    <text x="830" y="270" font-size="11" fill="#334155">• <strong>Colecciones:</strong> pizzas, pedidos, clientes</text>
    <text x="830" y="290" font-size="11" fill="#334155">• <strong>Aislamiento:</strong> Volumen temporal en test</text>
    <text x="830" y="310" font-size="11" fill="#334155">• <strong>Seguridad:</strong> Autenticación &amp; TLS opcional</text>
    <text x="830" y="335" font-size="11" font-weight="bold" fill="#10b981">ESTADO: HEALTHCHECK PASSED</text>
  </g>

  <!-- CLIENTES Y CONSUMIDORES EN PRUEBA -->
  <rect x="80" y="390" width="500" height="190" rx="10" fill="#ffffff" stroke="#cbd5e1" filter="url(#shadow2)"/>
  <rect x="80" y="390" width="500" height="30" rx="10" fill="#334155"/>
  <text x="330" y="411" font-size="12" font-weight="bold" fill="#ffffff" text-anchor="middle">CLIENTE WEB &amp; FRONTEND (React + Vite - Puerto 5173)</text>
  <text x="100" y="445" font-size="11" fill="#475569">• <strong>Pruebas de Componentes:</strong> Carrito de compras, catálogo reactivo</text>
  <text x="100" y="470" font-size="11" fill="#475569">• <strong>Pruebas de Integración Web:</strong> Axios interceptors, JWT localStorage</text>
  <text x="100" y="495" font-size="11" fill="#475569">• <strong>Responsive Testing:</strong> Visualización fluida en escritorio y tablet</text>
  <text x="100" y="520" font-size="11" fill="#475569">• <strong>Saneamiento XSS:</strong> React DOM escaping nativo validado</text>

  <rect x="630" y="390" width="500" height="190" rx="10" fill="#ffffff" stroke="#cbd5e1" filter="url(#shadow2)"/>
  <rect x="630" y="390" width="500" height="30" rx="10" fill="#4338ca"/>
  <text x="880" y="411" font-size="12" font-weight="bold" fill="#ffffff" text-anchor="middle">CLIENTE MÓVIL (React Native Android 14+ - APK)</text>
  <text x="650" y="445" font-size="11" fill="#475569">• <strong>Entorno Móvil:</strong> Emulador y APK Release probada en Android API 34</text>
  <text x="650" y="470" font-size="11" fill="#475569">• <strong>Módulos Probados:</strong> Selección de ingredientes, geolocalización Popayán</text>
  <text x="650" y="495" font-size="11" fill="#475569">• <strong>Offline Mode:</strong> Manejo de conectividad intermitente en despacho</text>
  <text x="650" y="520" font-size="11" fill="#475569">• <strong>Consumo API:</strong> Peticiones HTTPS a microservicio Go con Auth Bearer</text>
</svg>"""

# ------------------------------------------------------------------------------
# DIAGRAMA 3: CRONOGRAMA DE EJECUCIÓN DEL PLAN DE PRUEBAS (GANTT)
# ------------------------------------------------------------------------------
svg_d3 = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 550" width="1200" height="550" style="background:#ffffff; font-family:'Segoe UI', system-ui, sans-serif;">
  <defs>
    <filter id="shadow3" x="-5%" y="-5%" width="110%" height="115%"><feDropShadow dx="2" dy="4" stdDeviation="4" flood-opacity="0.12"/></filter>
  </defs>

  <rect x="20" y="20" width="1160" height="60" rx="8" fill="#f8fafc" stroke="#cbd5e1"/>
  <text x="40" y="55" font-size="18" font-weight="bold" fill="#065f46">CRONOGRAMA DE EJECUCIÓN DEL PLAN DE PRUEBAS (PLANIFICACIÓN TEMPORAL)</text>
  <text x="1150" y="55" font-size="12" font-weight="bold" fill="#64748b" text-anchor="end">4 SEMANAS • METODOLOGÍA ÁGIL</text>

  <!-- CABECERA DE TIEMPO (SEMANAS) -->
  <rect x="350" y="100" width="190" height="35" fill="#065f46"/>
  <text x="445" y="122" font-size="12" font-weight="bold" fill="#ffffff" text-anchor="middle">SEMANA 1</text>
  
  <rect x="545" y="100" width="190" height="35" fill="#047857"/>
  <text x="640" y="122" font-size="12" font-weight="bold" fill="#ffffff" text-anchor="middle">SEMANA 2</text>
  
  <rect x="740" y="100" width="190" height="35" fill="#059669"/>
  <text x="835" y="122" font-size="12" font-weight="bold" fill="#ffffff" text-anchor="middle">SEMANA 3</text>
  
  <rect x="935" y="100" width="190" height="35" fill="#10b981"/>
  <text x="1030" y="122" font-size="12" font-weight="bold" fill="#ffffff" text-anchor="middle">SEMANA 4</text>

  <!-- LÍNEAS GUÍA -->
  <line x1="350" y1="135" x2="350" y2="480" stroke="#e2e8f0" stroke-width="1.5"/>
  <line x1="540" y1="135" x2="540" y2="480" stroke="#e2e8f0" stroke-width="1.5"/>
  <line x1="735" y1="135" x2="735" y2="480" stroke="#e2e8f0" stroke-width="1.5"/>
  <line x1="930" y1="135" x2="930" y2="480" stroke="#e2e8f0" stroke-width="1.5"/>
  <line x1="1125" y1="135" x2="1125" y2="480" stroke="#e2e8f0" stroke-width="1.5"/>

  <!-- TAREAS GANTT -->
  <!-- T1: Análisis de Requerimientos -->
  <rect x="50" y="150" width="280" height="35" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>
  <text x="65" y="172" font-size="11.5" font-weight="bold" fill="#1e293b">1. Análisis Requisitos &amp; RTM</text>
  <rect x="350" y="153" width="180" height="28" rx="4" fill="#0284c7"/>
  <text x="440" y="171" font-size="10.5" font-weight="bold" fill="#ffffff" text-anchor="middle">100% Completado</text>

  <!-- T2: Configuración de Ambientes Docker -->
  <rect x="50" y="200" width="280" height="35" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>
  <text x="65" y="222" font-size="11.5" font-weight="bold" fill="#1e293b">2. Entornos Docker &amp; Mocks</text>
  <rect x="420" y="203" width="170" height="28" rx="4" fill="#6366f1"/>
  <text x="505" y="221" font-size="10.5" font-weight="bold" fill="#ffffff" text-anchor="middle">Docker Compose OK</text>

  <!-- T3: Pruebas Unitarias de Lógica -->
  <rect x="50" y="250" width="280" height="35" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>
  <text x="65" y="272" font-size="11.5" font-weight="bold" fill="#1e293b">3. Pruebas Unitarias (TDD)</text>
  <rect x="545" y="253" width="220" height="28" rx="4" fill="#059669"/>
  <text x="655" y="271" font-size="10.5" font-weight="bold" fill="#ffffff" text-anchor="middle">OrderCalculator / Auth OK</text>

  <!-- T4: Pruebas de Integración API REST -->
  <rect x="50" y="300" width="280" height="35" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>
  <text x="65" y="322" font-size="11.5" font-weight="bold" fill="#1e293b">4. Pruebas Integración API</text>
  <rect x="680" y="303" width="220" height="28" rx="4" fill="#0d9488"/>
  <text x="790" y="321" font-size="10.5" font-weight="bold" fill="#ffffff" text-anchor="middle">Go Fiber &amp; MongoDB OK</text>

  <!-- T5: Pruebas de Seguridad & OWASP -->
  <rect x="50" y="350" width="280" height="35" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>
  <text x="65" y="372" font-size="11.5" font-weight="bold" fill="#1e293b">5. Seguridad &amp; Saneamiento</text>
  <rect x="740" y="353" width="200" height="28" rx="4" fill="#d97706"/>
  <text x="840" y="371" font-size="10.5" font-weight="bold" fill="#ffffff" text-anchor="middle">XSS / NoSQL / RBAC</text>

  <!-- T6: Pruebas de Carga & Cierre -->
  <rect x="50" y="400" width="280" height="35" rx="6" fill="#f8fafc" stroke="#cbd5e1"/>
  <text x="65" y="422" font-size="11.5" font-weight="bold" fill="#1e293b">6. Carga, Regresión &amp; Cierre</text>
  <rect x="880" y="403" width="245" height="28" rx="4" fill="#e11d48"/>
  <text x="1000" y="421" font-size="10.5" font-weight="bold" fill="#ffffff" text-anchor="middle">Informe Final &amp; Pase Prod</text>

  <rect x="50" y="460" width="1075" height="40" rx="6" fill="#f1f5f9" stroke="#cbd5e1"/>
  <text x="70" y="485" font-size="11" fill="#475569">Responsable: <strong>Karen Yuliana Campo</strong> (QA Lead / Aprendiz ADSO Ficha 3186681) | Estado: <strong>100% Ejecutado y Aprobado</strong></text>
</svg>"""

diagrams = [
  ('ciclo_vida_pruebas_software_ieee829', svg_d1, 1200, 650),
  ('arquitectura_ambientes_pruebas_docker', svg_d2, 1200, 650),
  ('cronograma_plan_pruebas_gantt', svg_d3, 1200, 550)
]

for name, svg_code, w, h in diagrams:
    spath = os.path.join(DIAG_DIR, f"{name}.svg")
    ppath = os.path.join(DIAG_DIR, f"{name}.png")
    dpath = os.path.join(DIAG_DIR, f"{name}.drawio")
    hpath = os.path.join(DIAG_DIR, f"{name}_render.html")

    with open(spath, 'w', encoding='utf-8') as f:
        f.write(svg_code)

    # Render HTML
    html_render = f"<!DOCTYPE html><html><body style='margin:0;padding:0;overflow:hidden;'><img src='file://{spath}' style='width:{w}px;height:{h}px;'></body></html>"
    with open(hpath, 'w', encoding='utf-8') as f:
        f.write(html_render)

    cmd = [
        'google-chrome',
        '--headless',
        '--disable-gpu',
        f'--window-size={w},{h}',
        '--hide-scrollbars',
        f'--screenshot={ppath}',
        hpath
    ]
    res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if res.returncode == 0 and os.path.exists(ppath):
        size_kb = os.path.getsize(ppath) / 1024
        print(f"Diagrama PNG generado: {name}.png ({size_kb:.1f} KB)")

    # Drawio XML
    drawio_xml = f"""<mxfile host="Electron" version="21.0.0"><diagram id="{name}" name="{name}"><mxGraphModel dx="{w}" dy="{h}" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="{w}" pageHeight="{h}"><root><mxCell id="0"/><mxCell id="1" parent="0"/><mxCell id="box" value="{name}" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#059669;fontColor=#ffffff;fontSize=14;fontStyle=1;" vertex="1" parent="1"><mxGeometry x="100" y="100" width="300" height="80" as="geometry"/></mxCell></root></mxGraphModel></diagram></mxfile>"""
    with open(dpath, 'w', encoding='utf-8') as f:
        f.write(drawio_xml)
