package com.sena.pizzeria;

import com.sena.pizzeria.dto.ItemPedidoDTO;
import com.sena.pizzeria.dto.PedidoRequestDTO;
import com.sena.pizzeria.entity.Cliente;
import com.sena.pizzeria.entity.Pizza;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Pruebas unitarias automatizadas de validación de datos (Bean Validation).
 * Evidencia: GA7-220501096-AA3-EV02
 * 
 * Verifica restricciones de tipos de datos, longitudes, rangos numéricos y formatos regex.
 * 
 * @author Karen Yuliana Campo
 * @version 1.0.0
 */
public class PizzeriaValidationTests {

    private static Validator validator;

    @BeforeAll
    static void setUp() {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }

    @Test
    @DisplayName("VAL01 - Cliente Válido: Pasa todas las restricciones")
    void testClienteValido() {
        Cliente cliente = new Cliente("Valentina Rios", "3124567890", "Carrera 9 # 10-25, Popayán");
        Set<ConstraintViolation<Cliente>> violations = validator.validate(cliente);
        assertTrue(violations.isEmpty(), "Un cliente con datos correctos no debe generar violaciones");
    }

    @Test
    @DisplayName("VAL02 - Validación Cliente: Nombre vacío y longitud insuficiente")
    void testClienteNombreInvalido() {
        Cliente cliente = new Cliente("", "3124567890", "Calle Real");
        Set<ConstraintViolation<Cliente>> violations = validator.validate(cliente);
        assertFalse(violations.isEmpty(), "El nombre en blanco debe generar violación");
        assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("nombre")));
    }

    @Test
    @DisplayName("VAL03 - Validación Cliente: Teléfono con formato o caracteres inválidos")
    void testClienteTelefonoInvalido() {
        Cliente cliente = new Cliente("Andrés Paz", "312-ABC-99", "Calle 5 # 4-20");
        Set<ConstraintViolation<Cliente>> violations = validator.validate(cliente);
        assertFalse(violations.isEmpty(), "Teléfono con letras o guiones debe fallar la expresión regular");
        assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("telefono")));
    }

    @Test
    @DisplayName("VAL04 - Validación Pizza: Precio por debajo del límite mínimo permitido")
    void testPizzaPrecioMinimo() {
        Pizza pizza = new Pizza("Pizza Económica", "Personal", new BigDecimal("3500.00")); // Mínimo 5000 COP
        Set<ConstraintViolation<Pizza>> violations = validator.validate(pizza);
        assertFalse(violations.isEmpty(), "Precio menor a $5.000 COP debe generar violación");
        assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("precio")));
    }

    @Test
    @DisplayName("VAL05 - Validación Pedido DTO: Lista de ítems vacía y cliente nulo")
    void testPedidoDTOValidacion() {
        PedidoRequestDTO pedido = new PedidoRequestDTO(null, "En Preparación", Collections.emptyList());
        Set<ConstraintViolation<PedidoRequestDTO>> violations = validator.validate(pedido);
        assertEquals(2, violations.size(), "Debe detectar idCliente nulo e items vacíos");
    }

    @Test
    @DisplayName("VAL06 - Validación Ítem de Pedido: Cantidad menor a 1 unidad")
    void testItemPedidoCantidadInvalida() {
        ItemPedidoDTO item = new ItemPedidoDTO(1, 0); // Cantidad 0 inválida
        Set<ConstraintViolation<ItemPedidoDTO>> violations = validator.validate(item);
        assertFalse(violations.isEmpty(), "Cantidad menor a 1 debe generar violación");
        assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("cantidad")));
    }
}
